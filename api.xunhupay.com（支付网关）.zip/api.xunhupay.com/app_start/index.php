<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'class-xh-web-config.php';
require_once 'class-xh-application.php';

new XH_Application();