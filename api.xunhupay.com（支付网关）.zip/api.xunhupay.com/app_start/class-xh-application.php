<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once ABSPATH.'infrastructure/abstract-xh-application.php';
class XH_Application extends XH_Abstract_Application{
	
}