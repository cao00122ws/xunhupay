<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
require_once ABSPATH.'infrastructure/class-application-context-web.php';	
final class XH_Web_Config{
	 const DB_PANEL='web';
    /**
     * 网站根目录
     * @var string
     */
    const DOCUMENT_ROOT ='/';
    const ROLE_ADMIN='admin';
    const ROLE_MEMBER='member';
    const ROLE_MEMBER_EMPLOYEE='employee';
    const Rewrite_Url='https://www.xunhupay.com';
    
    //账户过期提醒
    const Wechat_Msg_Template_Account_expired='PMQlcF8h1QBU7sgE5ZCOj-SOwYlYlk_c1stX55LsRLM';
    
    //充值通知
    const Wechat_Msg_Template_Account_Rechagge='Rl15eJ6g2yhdhNN-hYrDJ0KWcgpIy8ga7FPPzFVALQ8';
    
    //提现到账通知
    const Wechat_Msg_Template_Withdraw_Completed='UVkmAt-pVFt27RLnN1ccsv-XhEiQ_q1rHo0dBNBrfeo';
  
    //提现申请通知
    const Wechat_Msg_Template_Withdraw_Created='moPjcEgV1Pdi_VRhDSq_UYqmOKjDZb-bd45-13KTEhY';
    
  
  //	应用审核通过
    const Wechat_V_SUCCESS = 'VtMi8wJPceKKKdkE1WH07P1TpWpGv1bnYOOkIMUIXPc';
    //最新订单信息提醒
    const Wechat_Msg_Template_Order_New='KE5_OxK0UQLfelemzL10Z99YY64LSi1y-K4AXWeYUbE';
    
  
    //会员过期提醒
    const Wechat_Msg_Template_Member_Expired='zaXlrG64QlOaYIyd0Afl5gYu-g_lWMKqaprs_IKfk6g';
    
	//areas
	public static $areas=array(
			'payments',
	        'service'
	);
  
    const GATEWAY ='https://api.xunhupay.com/payment/do.html';
    const WECHAT_APPID='2147483647';
    const WECHAT_APPSECRET='160130736b1ac0d54ed7abe51e44840b';
  
    const ALI_APPID='201906121218';
    const ALI_APPSECRET='a8e148a362ba032d7a2087a56171d927';
}