<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
class XH_Area_Registration extends XH_Abstract_Area_Registration {
	/**
	 * 获取area
	 */
	public function get_area() {
		return '';
	}
	
	/**
	 * 注册路由
	 * 
	 * @param XH_Route_Conllection $routes        	
	 */
	public function register_routes($routes) {
		/*-=-=-=-=-=-=-=-=-=-account=-=-=-=-=-=-=-=-=-=-=-=-=*/
	    $routes->map_route('', array(
	        'action'=>'index',
	        'controller'=>'home'
	    ));
	    
	    $routes->map_route('qrcode/{appid}.html', array(
	        'action'=>'qrcode',
	        'controller'=>'plugins',
	        'params'=>array(
	            'appid'=>'\d+'
	        )
	    ));
	    
		$routes->map_route('forbidden.html', array(
				'action'=>'forbidden',
				'controller'=>'home'
		));
		
		/*-=-=-=-=-=-=-=-=-=-account end-=-=-=-=-=-=-=-=-=-=-=*/
	}
}