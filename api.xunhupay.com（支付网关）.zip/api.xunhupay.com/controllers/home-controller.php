<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class Home_Controller extends XH_Abstract_Controller{
	public function index(){
	    return $this->redirect_url(XH_Web_Config::Rewrite_Url);
	}
	
	public function forbidden(){
	    return $this->view_result();
	}
	
}