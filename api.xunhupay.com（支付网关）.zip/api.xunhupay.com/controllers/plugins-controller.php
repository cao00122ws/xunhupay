<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';

class Plugins_Controller extends Web_Abstract_Controller{
    
    public function qrcode(){ 
        $data = array(
            'appid'=>isset($_GET['appid'])?$_GET['appid']:'',
            'time'=>isset($_GET['time'])?$_GET['time']:'',
            'nonce_str'=>isset($_GET['nonce_str'])?$_GET['nonce_str']:'',
            'data'=>isset($_GET['data'])?$_GET['data']:'',
            'filename'=>isset($_GET['filename'])?$_GET['filename']:'',
            'hash'=>isset($_GET['hash'])?$_GET['hash']:'',
        );
      
        $app =null;
        try {
            //链接在5*60秒内可无线刷新
            $request =$this->authorize($data, false,30*60);
           
            $app = $request['app'];
        } catch (Exception $e) { 
            $logger = new XH_Log();
            $logger->ERROR($e->getMessage());
            return $this->content_result('');
        }
       
        $value = base64_decode($data['data']);
        $filename = $data['filename'];
        
        if(!empty($filename)){
            $filename = base64_decode($filename);
            preg_match_all('/[\x{4e00}-\x{9fff}a-zA-Z\d\-_]+/u', $filename, $matches);
            $filename = join('', $matches[0]);
        }
    
        if(!class_exists('QRcode')){
            require_once ABSPATH.'infrastructure/lib/phpqrcode/phpqrcode.php';
        }
    
        $errorCorrectionLevel = 'L'; // 容错级别
        $matrixPointSize = 9; // 生成图片大小
        $logopath = null;//ABSPATH . '/content/images/qrcode/default.png';
    
        $QR = QRcode::image ( $value, $errorCorrectionLevel, $matrixPointSize, 1 );
    
        // 生成二维码图片
        if ($logopath) {
            $logo = imagecreatefrompng ( $logopath );
            if ($logo) {
                $QR_width = imagesx ( $QR ); // 二维码图片宽度
                $QR_height = imagesy ( $QR ); // 二维码图片高度
    
                $logo_width = imagesx ( $logo ); // logo图片宽度
                $logo_height = imagesy ( $logo ); // logo图片高度
    
                $logo_qr_width = $QR_width / 5;
                $scale = $logo_width / $logo_qr_width;
    
                $logo_qr_height = $logo_height / $scale;
                $from_width = ($QR_width - $logo_qr_width) / 2;
    
                // 重新组合图片并调整大小
                imagecopyresampled ( $QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height );
            }
        }
    
        ob_clean();
        if(empty($filename)){
            header ( "Content-type: image/png" );
        }else{
            Header("Content-Disposition: attachment; filename=$filename.png");
        }
        imagepng ( $QR );
        exit;
    }
}