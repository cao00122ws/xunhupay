
(function(){
	window.shopping_cart ={
			__key:'shopping_cart',
			clear:function(){
				$.cookie(this.__key,null);
				this.__items=[];
			},
			init:function(products){
				$.cookie.json = true;
				this.__items = $.cookie(this.__key);
				if(!this.__items||typeof this.__items.push=='undefined'){
					this.__items = [];
				}
				
				var items =[];
				for(var index=0;index<this.__items.length;index++){
					var shopping_cart_item =this.__items[index];
					
					var product =htmlhelper.firstOrDefault(products,function(m){return m.id==shopping_cart_item.id;})
					if(product==null){
						continue;
					}
					if(product.inventory==null||product.inventory.length==0){
						product.inventory = 999;
					}
					product.inventory = htmlhelper.parseInt(product.inventory,0);
					if(product.inventory<0){product.inventory=0;}
					if(shopping_cart_item.qty>product.inventory){
						shopping_cart_item.qty=product.inventory;
					}
					
					shopping_cart_item.name = product.name;
					shopping_cart_item.sale_price =product.sale_price;
					items.push(shopping_cart_item);
				}
		
				this.__items=items;
				$.cookie(this.__key, this.__items, {  path: '/' });
			},
			__items:[],
			add_shopping_cart_item:function(product){
				var shopping_cart_item = window.shopping_cart.get_shopping_cart_item(product.id);			
				if(shopping_cart_item!=null){
					shopping_cart_item.qty=product.qty;
				}else{
					this.__items.push(product);
				}
				
				$.cookie.json = true;
				$.cookie(this.__key, this.__items, {  path: '/' });
			},
			remove_shopping_cart_item:function(product_id){
				var shopping_cart_item = window.shopping_cart.get_shopping_cart_item(product_id);
				if(shopping_cart_item==null){
					return;
				}
				
				shopping_cart_item.qty--;
				if(shopping_cart_item.qty<=0){
					this.__items = htmlhelper.where(this.__items,function(m){return m.id!=product_id;});
				}
				
				$.cookie.json = true;
				$.cookie(this.__key, this.__items, { expires: 3, path: '/' });
			},
			get_shopping_cart_item:function(product_id){
				return htmlhelper.firstOrDefault(this.__items,function(m){
					return m.id ==product_id;
				});
			},
			clear:function(){
				this.__items=[];
			},
			get_shopping_cart_items:function(){
				return this.__items;
			}
	};
	
})();

