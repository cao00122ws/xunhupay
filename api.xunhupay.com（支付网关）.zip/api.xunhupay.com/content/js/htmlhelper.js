﻿
/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2006, 2014 Klaus Hartl
 * Released under the MIT license
 */
(function (factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD (Register as an anonymous module)
		define(['jquery'], factory);
	} else if (typeof exports === 'object') {
		// Node/CommonJS
		module.exports = factory(require('jquery'));
	} else {
		// Browser globals
		factory(jQuery);
	}
}(function ($) {

	var pluses = /\+/g;

	function encode(s) {
		return config.raw ? s : encodeURIComponent(s);
	}

	function decode(s) {
		return config.raw ? s : decodeURIComponent(s);
	}

	function stringifyCookieValue(value) {
		return encode(config.json ? JSON.stringify(value) : String(value));
	}

	function parseCookieValue(s) {
		if (s.indexOf('"') === 0) {
			// This is a quoted cookie as according to RFC2068, unescape...
			s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
		}

		try {
			// Replace server-side written pluses with spaces.
			// If we can't decode the cookie, ignore it, it's unusable.
			// If we can't parse the cookie, ignore it, it's unusable.
			s = decodeURIComponent(s.replace(pluses, ' '));
			return config.json ? JSON.parse(s) : s;
		} catch(e) {}
	}

	function read(s, converter) {
		var value = config.raw ? s : parseCookieValue(s);
		return $.isFunction(converter) ? converter(value) : value;
	}

	var config = $.cookie = function (key, value, options) {

		// Write

		if (arguments.length > 1 && !$.isFunction(value)) {
			options = $.extend({}, config.defaults, options);

			if (typeof options.expires === 'number') {
				var days = options.expires, t = options.expires = new Date();
				t.setMilliseconds(t.getMilliseconds() + days * 864e+5);
			}

			return (document.cookie = [
				encode(key), '=', stringifyCookieValue(value),
				options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
				options.path    ? '; path=' + options.path : '',
				options.domain  ? '; domain=' + options.domain : '',
				options.secure  ? '; secure' : ''
			].join(''));
		}

		// Read

		var result = key ? undefined : {},
			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all. Also prevents odd result when
			// calling $.cookie().
			cookies = document.cookie ? document.cookie.split('; ') : [],
			i = 0,
			l = cookies.length;

		for (; i < l; i++) {
			var parts = cookies[i].split('='),
				name = decode(parts.shift()),
				cookie = parts.join('=');

			if (key === name) {
				// If second argument (value) is a function it's a converter...
				result = read(cookie, value);
				break;
			}

			// Prevent storing a cookie that we couldn't decode.
			if (!key && (cookie = read(cookie)) !== undefined) {
				result[name] = cookie;
			}
		}

		return result;
	};

	config.defaults = {};

	$.removeCookie = function (key, options) {
		// Must not alter options, thus extending a fresh object...
		$.cookie(key, '', $.extend({}, options, { expires: -1 }));
		return !$.cookie(key);
	};

}));
/**
 * paging helper == must be place end
 *
*/
;(function () {
	"use strict";

	window.htmlhelper = {
			//监听浏览器回退事件
		history:{
			back:function(callback){
				!function(pkg, undefined){
					var STATE = 'x-back';
					var element;

					var onPopState = function(event){
					    event.state === STATE && fire();
					    record(STATE);  //初始化事件时，push一下
					}

					var record = function(state){
						var i=1;
					    while(i-->=0){
					    	history.pushState(state, null, location.href);
						}
					}

					var fire = function(){
					    var event = document.createEvent('Events');
					    event.initEvent(STATE, false, false);
					    element.dispatchEvent(event);
					}

					var listen = function(listener){
					    element.addEventListener(STATE, listener, false);
					}

					!function(){
					    element = document.createElement('span');
					    window.addEventListener('popstate', onPopState);
					    this.listen = listen;
					    record(STATE);   
					}.call(window[pkg] = window[pkg] || {});
		    	}('XBack');
		    	
		    	XBack.listen(callback);
			}
		},
		add:function(l,r){
			l = this.parseFloat(l,0);
			r = this.parseFloat(r,0);
			
			var lstr = l.toString();
			var rstr =r.toString();
			var lindexof =lstr.indexOf('.');
			var rindexof =rstr.indexOf('.');
			
			var index1 =lindexof==-1?0:(lstr.length- lstr.indexOf('.')-1);
			var index2 =rindexof==-1?0:(rstr.length- rstr.indexOf('.')-1);
			
			var len = Math.max(index1,index2);
			var big =Math.pow(10,len);
			
			return parseFloat(((l*big+r*big)/big).toFixed(2));
		},
		cut:function(l,r){
			l = this.parseFloat(l);
			r = this.parseFloat(r);
			
			var lstr = l.toString();
			var rstr =r.toString();
			var lindexof =lstr.indexOf('.');
			var rindexof =rstr.indexOf('.');
			
			var index1 =lindexof==-1?0:(lstr.length- lstr.indexOf('.')-1);
			var index2 =rindexof==-1?0:(rstr.length- rstr.indexOf('.')-1);
			
			var len = Math.max(index1,index2);
			var big =Math.pow(10,len);
			
			return parseFloat(((l*big-r*big)/big).toFixed(2));
		},
		//乘法
		multi:function(l,r){
			l = this.parseFloat(l);
			r = this.parseFloat(r);
			
			var lstr = l.toString();
			var rstr =r.toString();
			var lindexof =lstr.indexOf('.');
			var rindexof =rstr.indexOf('.');
			
			var index1 =lindexof==-1?0:(lstr.length- lstr.indexOf('.')-1);
			var index2 =rindexof==-1?0:(rstr.length- rstr.indexOf('.')-1);
			
			var len = Math.max(index1,index2);
			var big =Math.pow(10,len);
			
			return parseFloat((((l*big)*(r*big))/(big*big)).toFixed(2));
		},
		ifnullOrEmpty: function(source, $default) {
			if (htmlhelper.isNullOrEmpty(source)) {
				return $default;
			}

			return source;
		},
		isNullOrEmpty: function(source) {
			return (typeof source == "undefined" || source == null || source.length === 0);
		},
		removeAt: function(array, func) {
			if (htmlhelper.isNullOrEmpty(array)) {
				return array;
			}

			var indexof = htmlhelper.indexOf(array, func);

			if (indexof < 0) {
				return array;
			}

			return array.splice(indexof, 1);
		},
		isNullOrWhitespace: function(source) {
			if (window.htmlhelper.isNullOrEmpty(source)) {
				return true;
			}

			for (var index = 0; index < source.length; index++) {
				if (!window.htmlhelper.isNullOrEmpty(source[index])) {
					return false;
				}
			}

			return true;
		},
		parseInt: function(source, defaultInt) {
			if (typeof defaultInt === 'undefined') {
				defaultInt = 0;
			}
			if (htmlhelper.isNullOrEmpty(source)) {
				return defaultInt;
			}

			var value = parseInt(source);
			if (isNaN(value)) {
				value = defaultInt;
			}

			return value;
		},
		parseFloat: function(source, defaultInt) {
			if (typeof defaultInt === 'undefined') {
				defaultInt = 0;
			}

			if (htmlhelper.isNullOrEmpty(source)) {
				return defaultInt;
			}

			var value = parseFloat(source);
			if (isNaN(value)) {
				value = defaultInt;
			}

			return value;
		},
		ajaxError: function(e) {
			htmlhelper.dialog.loading.hide();
			htmlhelper.dialog.error('网络异常，请稍候重试！');
			console.warn(e.responseText);
		},
		mergerError: function (result, onSuccessCallback) {
			if (result.success) {
				onSuccessCallback(result);
				return false;
			}

			if(result.isUnAuth){
				htmlhelper.dialog.warning('您未授权访问当前页面，请刷新页面后重试！');
				return;
			}
			
			htmlhelper.dialog.warning(result.message);
			return true;
		},
		firstOrDefault: function(array, where) {
			if (htmlhelper.isNullOrEmpty(array)) {
				return null;
			}

			for (var index = 0; index < array.length; index++) {
				var item = array[index];
				if (!where) {
					return item;
				}

				if (where(item)) {
					return item;
				}
			}

			return null;
		},
		select: function(array, selector) {
			if (htmlhelper.isNullOrEmpty(array)) {
				return null;
			}

			if (array == null) {
				return array;
			}

			var newArray = [];
			for (var index = 0; index < array.length; index++) {
				var item = array[index];
				newArray.push(selector(item));
			}

			return newArray;
		},
		any: function(array, where) {
			if (htmlhelper.isNullOrEmpty(array)) {
				return false;
			}

			if (where == null) {
				return true;
			}

			for (var index = 0; index < array.length; index++) {
				if (where(array[index])) {
					return true;
				}
			}

			return false;
		},
		all: function (array, where) {
			if (htmlhelper.isNullOrEmpty(array)) {
				return false;
			}

			if (where == null) {
				return false;
			}

			for (var index = 0; index < array.length; index++) {
				if (!where(array[index])) {
					return false;
				}
			}

			return true;
		},
		indexOf: function (array, where) {
			if (array == null) {
				return -1;
			}

			if (where == null) {
				return -1;
			}

			for (var index = 0; index < array.length; index++) {
				if (where(array[index])) {
					return index;
				}
			}

			return -1;
		},
		where: function (array, where) {
			if (array == null) {
				return null;
			}

			if (where == null) {
				return null;
			}

			var array1 = [];
			for (var index = 0; index < array.length; index++) {
				if (where(array[index])) {
					array1.push(array[index]);
				}
			}

			return array1;
		},
		integer: function (source) {
			if (typeof source !== 'number') {
				return parseInt(source);
			}

			return source;
		},
		isDecimal: function (source) {
			if (htmlhelper.isNullOrEmpty(source)) {
				return false;
			}

			var regex = /^\d+(\.\d+)?$/;
			return regex.test(source);
		},
		isInteger: function (source) {
			if (htmlhelper.isNullOrEmpty(source)) {
				return false;
			}

			var regex = /^\d+$/;
			return regex.test(source);
		},
		/*
		 @param array Array
		 @param selector function(item,index){}
		*/
		array2string: function (array, selector) {
			var content = '';
			if (array == null) {
				return content;
			}

			if (selector == null) {
				return content;
			}

			for (var i = 0; i < array.length; i++) {
				content += selector(array[i], i);
			}

			return content;
		},
		replace:function(array, newitem, func) {
			if (array == null) {
				return;
			}

			for (var index = 0; index < array.length; index++) {
				if (func(array[index])) {
					array[index] = newitem;
					return;
				}
			}
		} ,
		replaceAll:function(array, newitem, func) {
			if (array == null) {
				return;
			}

			for (var index = 0; index < array.length; index++) {
				if (func(array[index])) {
					array[index] = newitem;
				}
			}
		},
		each: function (array, func) {
		    if (array == null) {
		        return;
		    }

		    for (var index = 0; index < array.length; index++) {
		        func(array[index], index);
		    }
		},
		sum: function (source, selector) {
			if (htmlhelper.isNullOrEmpty(source)) {
				return 0;
			}

			var sum = 0;
			for (var index = 0; index < source.length; index++) {
				sum = this.add(sum, selector(source[index]));
			}

			return sum;
		},
        __callWeixin:function(){
            if(!window.__waittingWeixinCallbackEvents){
                return;
            } 
            
            for(var i=0;i<window.__waittingWeixinCallbackEvents.length;window.__waittingWeixinCallbackEvents++){
                window.__waittingWeixinCallbackEvents[i]();
            }
        },
        callWeixin:function(callback){
            if(!htmlhelper.isWeixinClient()){
                htmlhelper.dialog.alert('请在微信客户端打开链接');
                return;
            }
            
            var WeixinJSBridge = window.WeixinJSBridge;
           
            
            if (typeof WeixinJSBridge === "undefined") {
                if(!window.__waittingWeixinCallbackEvents){
                   window.__waittingWeixinCallbackEvents=[];
                }
            
                window.__waittingWeixinCallbackEvents.push(callback);
            
                if (document.addEventListener) {
                    document.addEventListener('WeixinJSBridgeReady', htmlhelper.__callWeixin, false);
                } else if (document.attachEvent) {
                    document.attachEvent('WeixinJSBridgeReady', htmlhelper.__callWeixin);
                    document.attachEvent('onWeixinJSBridgeReady', htmlhelper.__callWeixin);
                }
            } else {
                callback();
            }
        },
        isWeixinClient:function(){
            var ua = navigator.userAgent.toLowerCase();
            var isWeixin = ua.indexOf('micromessenger') != -1;
            //var isAndroid = ua.indexOf('android') != -1;
            //var isIos = (ua.indexOf('iphone') != -1) || (ua.indexOf('ipad') != -1);
            return isWeixin;
        },
        get_img_thumb:function(img,width,height){
        	if(img==null){
        		return img;
        	}
        	
        	var index =img.lastIndexOf('.');
        	if(index<0){
        		return img;
        		
        	}
        	return  img.substr(0,index) + '-' + width +'x' + height+'.' + img.substr(index+1);
        },
        ajax:function(url,data,success,error,options){
        	$.ajax({
			      url:url,
			      type:'post',
			      timeout: 60 * 1000,
			      async: true,
			      cache: false,
			      data:data,
			      beforeSend:function(){
			    	  if(options&&options.beforeSend){
						  options.beforeSend();return;
					  }
					 htmlhelper.dialog.loading.show();
				  },
				  complete:function(){
					  if(options&&options.complete){
						  options.complete();return;
					  }
					 htmlhelper.dialog.loading.hide();
				  },
			      dataType: 'json',
			      success: function(e) {
				      if(typeof e.errcode!='undefined'&&e.errcode!=0){
				    	  htmlhelper.dialog.warning(e.errmsg);
				    	  htmlhelper.dialog.loading.hide();
				    	  return;
				      }

				      if(success){
				    	  success(e);
				      }
				  },
				  error:function(e){
					  htmlhelper.dialog.loading.hide();
					  if(error){
						  error(e);return;
					  }
					  htmlhelper.ajaxError(e);
				  }
			});
        }
	};
})();

(function () {
	'use strict';
	window.htmlhelper.dialog = {
		alert: function (message) {
			if (htmlhelper.isNullOrEmpty(message)) {
				message = 'UNKNOW ERROR！';
			}

			$.alert(message);
		},
		success:function(msg){
			$.toptip(msg, 'success');
		},
		error:function(msg){
			$.toptip(msg, 'error');
		},
		warning:function(msg){
			$.toptip(msg, 'warning');
		},
		confirm: function (message, yes,no) {
			$.confirm(message,yes,no);
		},
		prompt: function (message, yes,no) {
			$.prompt('',message, yes,no);
		},
		loading: {
			show: function (msg) {
				if(htmlhelper.isNullOrEmpty(msg)){
					msg='加载中...';
				}
				
				$.showLoading(msg);
				$('.weui_toast.weui_loading_toast.weui_toast_visible').click(function(){
					$.hideLoading();
				});
			},
			hide: function () {
				$.hideLoading();
			}
		}
	};
})();


(function(){
	htmlhelper.shopping_cart ={
			__inited:false,
			__key:'shopping_cart',
			__items:null,
			init:function(shop_id,onsuccess,onfail){
				if(this.__inited){
					return;
				}
				
				this.__inited=true;
				
				$.cookie.json = true;
				var items =$.cookie(this.__key);
				if(!items||!items instanceof Array){
					items =[];
				}
				
				var data={
						shop_id:shop_id,
						shopping_cart_items:JSON.stringify(items)
				};
				
				$.ajax({
				      url:window.GLOBAL_CONFIG.shopping_cart.url.refresh,
				      type:'post',
				      timeout: 60 * 1000,
				      async: true,
				      cache: false,
				      data: data,
				      dataType: 'json',
				      beforeSend:function(){
						 	htmlhelper.dialog.loading.show();
					  },
					  complete:function(){
							 htmlhelper.dialog.loading.hide();
					  },
				      success: function(e) {
				    	  if(e.errcode!=0){
				    		  if(onfail){
								  onfail();
							  }
				    		  return;
				    	  }
				    	  
				    	  if(!e.data||!e.data instanceof Array){
				    		  e.data=[];
				    	  }
				    	  
				    	  htmlhelper.shopping_cart.__items=[];
				    	  htmlhelper.each(e.data,function(m){
				    		  m.qty =htmlhelper.parseInt(m.qty);
				    		  m.inventory =htmlhelper.parseInt(m.inventory);
				    		  m.sale_price =htmlhelper.parseFloat(m.sale_price);
				    		  
				    		  htmlhelper.shopping_cart.__items.push({
				    			  	product_sale_item_id:m.product_sale_item_id,
				    			  	qty:m.qty,
				    			  	inventory:m.inventory,
				    			  	sale_price:m.sale_price
				    		  });
				    	  });
				    	  
				    	  htmlhelper.shopping_cart.save();
				    	  if(onsuccess){
				    		  onsuccess(e.data);
				    	  }
				      },
					  error:function(e){
						  if(onfail){
							  onfail();
						  }
					  }
				});
				
				
			},
			clear:function(){
				this.__items=[];
				this.save();
			},
			save:function(){
				var expire= new Date();
				expire.setTime(expire.getTime() + (3* 24 *60 * 60 * 1000));
				var data =this.get_shopping_cart_items();
				$.cookie(this.__key,data, {  path: '/', expires : expire});
			},
			add:function(product_sale_item_id,sale_price,inventory){
				inventory = htmlhelper.parseInt(inventory,0);
				var shopping_cart_item = this.get_shopping_cart_item(product_sale_item_id);			
				if(shopping_cart_item!=null){
					shopping_cart_item.qty 						= htmlhelper.parseInt(shopping_cart_item.qty,0);
					if(shopping_cart_item.qty<=0){
						shopping_cart_item.qty=0;
					}
					
					
					shopping_cart_item.qty++;
					if(shopping_cart_item.qty>inventory){
						shopping_cart_item.qty=inventory;
					}
					if(shopping_cart_item.qty<=0){
						shopping_cart_item.qty=0;
					}
					
					shopping_cart_item.sale_price 				= sale_price;
					shopping_cart_item.product_sale_item_id		= product_sale_item_id;
					shopping_cart_item.inventory 				= inventory;
				}else{
					var shopping_cart_items = this.get_shopping_cart_items();
					shopping_cart_item = {};
					shopping_cart_item.qty						= 1;
					shopping_cart_item.sale_price 				= sale_price;
					shopping_cart_item.product_sale_item_id		= product_sale_item_id;
					shopping_cart_item.inventory 				= inventory;
					
					shopping_cart_items.push(shopping_cart_item);
				}
				
				this.save();
				return shopping_cart_item;
			},
			cut:function(product_sale_item_id){
				var shopping_cart_item 						= this.get_shopping_cart_item(product_sale_item_id);	
				if(shopping_cart_item==null){
					return null;
				}
				
				shopping_cart_item.qty 						= htmlhelper.parseInt(shopping_cart_item.qty,0);
				shopping_cart_item.qty--;
				if(shopping_cart_item.qty<=0){
					this.remove_shopping_cart_item(product_sale_item_id);
					return null;
				}
				
				this.save();
				return shopping_cart_item;
			},
			remove_shopping_cart_item:function(product_sale_item_id){
				var shopping_cart_items = this.get_shopping_cart_items();
				if(shopping_cart_items==null){
					return;
				}

				this.__items = htmlhelper.where(shopping_cart_items,function(m){return m.product_sale_item_id!=product_sale_item_id;});				
				this.save();
			},
			get_shopping_cart_item:function(product_sale_item_id){
				return htmlhelper.firstOrDefault(this.get_shopping_cart_items(),function(m){
					return m.product_sale_item_id == product_sale_item_id;
				});
			},
			get_shopping_cart_items:function(){
				if(!this.__items||!this.__items instanceof Array){
					this.__items=[];
				}
				
				var results = [];
				for(var i=0;i<this.__items.length;i++){
					var item = this.__items[i];
					var inventory = htmlhelper.parseInt(item.inventory,0);
					var qty = htmlhelper.parseInt(item.qty,0);
					if(qty>inventory){
						qty = inventory;
					}
					
					if(qty<=0){
						continue;
					}
					
					item.inventory = inventory;
					item.qty = qty;
					item.sale_price = htmlhelper.parseFloat(item.sale_price,0);
					results.push(item);
				}
				
				this.__items=results;
				return this.__items;
			}
	};
	
})();

