- [ ] Issue does not already exist
- [ ] Issue observed on https://plyr.io

### Expected behaviour 

### Actual behaviour

### Environment

- Browser:
- Version:  
- Operating System:
- Version: 

### Steps to reproduce 
- 

### Relevant links