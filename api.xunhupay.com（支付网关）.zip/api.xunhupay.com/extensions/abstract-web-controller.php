<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

abstract class Web_Abstract_Controller extends XH_Abstract_Controller {
    const cmbc_gateways_url="http://pay.jukebang.net/api/pay/core";
    const cib_gateways_url='https://pay.miaofupay.cn/api/pay/core';
    public static $SUCCESS=100,$FAIL=99;
    
    public function __construct(){
        
    }
    
    public function error_result($error){
        global $ViewBag;
        $ViewBag->set('error', $error);
        require_once ABSPATH.'/views/shared/_die.phtml' ;
        exit;
    }

    public function success_result($error){
        global $ViewBag;
        $ViewBag->set('success', $error);
        require_once ABSPATH.'/views/shared/_success.phtml' ;
        exit;
    }
   public function jsonp_result($json){
       if(!isset($_REQUEST['callback'])){
       		return $this->json_result($json);
       }
     
    	$callback = $_REQUEST['callback'];
	    header('Content-type: application/json');
		if($json instanceof XH_Error){
			print "{$callback}({$json->to_json()})" ;
			return;
		}	
		
		if(is_array($json)){
          $json = XH_Common::json_encode_ex($json);
			print "{$callback}({$json})" ;
			return;
		}
		
		
		$json = XH_Error::error_unknow();
     	print "{$callback}({$json->to_json()})" ;
	}
    
    public function hash_result($app,$errcode,$errmsg, array $data=array()){
        if(!$app){
            header("HTTP/1.0 $errcode $errmsg");
            return $this->content_result($errmsg);
        }
        
        $data['errcode'] =$errcode;
        $data['errmsg']=empty($errmsg)?'success!':$errmsg;//兼容老版本
      
        $data['hash']=$this->generate_xh_hash($data, $app->appkey);
        return $this->json_result($data);
    }
   
    protected function http_post($url,$data,$timeout=10,$ssl=0){
        global $Url;
        
        $user_agent ='Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13';
	    $ch = curl_init();
	    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
	    curl_setopt($ch, CURLOPT_URL, $url);
	    //https 
	    if($ssl==1){
    	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
    	    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
	    }
	    
	    if($ssl==2){
	        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,true);
	        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
            curl_setopt( $ch, CURLOPT_CAINFO, ABSPATH . WPINC . '/certificates/ca-bundle.crt');
	    }
	    
	    curl_setopt($ch, CURLOPT_HEADER, FALSE);
	    curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
	    curl_setopt($ch, CURLOPT_REFERER,$Url->route->host);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	    curl_setopt($ch, CURLOPT_POST, TRUE);
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	    $response = curl_exec($ch);
	    $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	    $error=curl_error($ch);
	    curl_close($ch);
	    if($httpStatusCode!=200){
	        //签名证书无法验证
	        if($httpStatusCode==0){
	            $isssl =stripos($error, 'certificate')!==false&&stripos($url, 'https')===0;
    	        if($ssl==0&&$isssl){
    	            return $this->http_post($url, $data,$timeout,1);
    	        }
    	        if($ssl==1&&$isssl){
    	            return $this->http_post($url, $data,$timeout,2);
    	        }
	        }
	        throw new Exception("invalid httpstatus:{$httpStatusCode} ,response:$response,detail_error:".$error,$httpStatusCode);
	    }
	    
	    return $response;
	}
	
	protected function notify_order($order_id,$transaction_id=''){
	    $order_id = absint($order_id);
	    global $wpdb;
	    $order = $wpdb->get_row(
            "select o.id,
        	        o.appid,
                    o.trade_order_id,
    				o.transaction_id,
        	        o.status,
                    a.id as appid,
                    o.total_amount,
                    o.order_date,
                    o.notify_url,
                    o.attach,
                    o.title,
                    a.appkey,
	                o.plugins,
    	            a.name as app_name,
                    o.check_callback_time,
                    a.member_id
	        from `order` o
	        inner join app a on a.id = o.appid
	        where o.id={$order_id}
	        limit 1;");
	         
	        if(!$order){
	            throw new Exception('unknow order',500);
	        }
	         
	        $status = array('WP');
	        
	        if(!in_array($order->status,$status)){
	            return;
	        }
	        
	        $sql = join("','", $status);
	        
	        $now =date_i18n('Y-m-d H:i:s');
            $success = self::$SUCCESS;
            $update_result =$wpdb->query($wpdb->prepare(
               "update `order` o
                inner join member_income mi on mi.order_id = o.id
                inner join member m on m.id = mi.member_id
                inner join member pa on pa.id = mi.parent_member_id
                set o.status='OD',
                    m.pt_amount = ROUND(m.pt_amount-mi.pt_amount,2),
	                o.check_paid_time=$success,
                    o.order_paid_date ='{$now}',
	                o.transaction_id=%s,
	                mi.status='P',
	                pa.income =ROUND(pa.income+mi.parent_income,2)
                where o.status in ('$sql')
    	              and mi.status='A'
    	              and o.id={$order->id};", $transaction_id));
            	
            if(!empty($wpdb->last_error)){
                throw new Exception($wpdb->last_error,500);
            }
            
            $order->transaction_id = $transaction_id;
            //没有订单信息可以更新
            if(!$update_result){
                return;
            }
            
	        //check_callback_time 0,1,2检查失败  100 检查成功
	       try {
	           $this->order_notify_callback($order);
	       } catch (Exception $e) {
	           $logger = new XH_Log();
	           $logger->ERROR($e->getMessage());
	       }
	        
      
       	    $member_with_customer = $wpdb->get_row(
	            "select m.id,
        	            m.wechat
	            from member m
	            where m.id=$order->member_id
	            limit 1;");
      
      	   $wechat = json_decode( $member_with_customer->wechat,true);
          if( $wechat&&isset( $wechat['openid'])){
            $this->order_ordered_msg(
               $wechat['openid'],
               $order
            );
          }
      
	       return true;
	}
  
	protected function order_ordered_msg($openid,$order){
	    global $wpdb;
	    try {
	        $wpdb->insert('message', array(
	            'content'=>json_encode(array(
	                'type'=>'wechat',
	                'openid'=>$openid,
	                'templete_id'=>XH_Web_Config::Wechat_Msg_Template_Order_New,
	                'url'=>'https://admin.xunhupay.com/orders/home/index',
	                'content'=>json_encode(array(
						'first'=>array(
	                        'value'=>$order->title."(金额：￥{$order->total_amount})",
	                        'color'=>'#000'
	                    ),
						'keyword1'=>array(
	                        'value'=>"{$order->id}",
	                        'color'=>'#000'
	                    ),
	                    'keyword2'=>array(
	                        'value'=>"{$order->order_date}",
	                        'color'=>'#000'
	                    ),
	                    'keyword3'=>array(
	                        'value'=>"金额：￥{$order->total_amount}，请留意网站订单！",
	                        'color'=>'#000'
	                    )
	                ))
	            )),
	            'created_time'=>date_i18n('Y-m-d H:i:s'),
	            'status'=>'A'
	        ));
	    } catch (Exception $e) {
	        $logger = new XH_Log ( 'member' );
	        $logger->ERROR ( $e->getMessage () );
	    }
	}
  
	protected function order_notify_callback($order){
	    global $wpdb;
	    $logger = new XH_Log();
	    
	    $app = new stdClass();
	    $app->id = $order->appid;
	    $app->appkey = $order->appkey;
	    
	    if(empty($order->notify_url)||$order->check_callback_time>=5){
	        return;
	    }
	    
	    //排除localhost请求
	    if(stripos($order->notify_url, 'http://localhost')===0||stripos($order->notify_url, 'https://localhost')===0){
	          $fail = self::$FAIL;
	          $wpdb->query(
	              "update `order` o
	               set o.check_callback_time=$fail
	               where o.id={$order->id};");
	           
	          if(!empty($wpdb->last_error)){
	              $logger->ERROR($wpdb->last_error);
	             
	          }
	        return;
	    }
	    
        $callback_data =array(
            'trade_order_id'=>$order->trade_order_id,
            'total_fee'=>$order->total_amount,
            'transaction_id'=>isset($order->transaction_id)&&!empty($order->transaction_id)?$order->transaction_id:$order->id,
            'open_order_id'=>$order->id,
            'order_title'=>$order->title,
            'status'=>'OD'
        );
        
        if($order->plugins){
            $callback_data['plugins']=$order->plugins;
        }
        if($order->attach){
        	 $callback_data['attach']=$order->attach;
        }
        $data = $this->generate_xh_hash_string($app,$callback_data);
        
        try {
            $response  = $this->http_post($order->notify_url, http_build_query($data));
          global $callback_error;
           $callback_error = $response;
          
            if(!$response){
                $logger->ERROR("appid:{$order->appid},orderid:{$order->id},errmsg:empty callback,details:$response");
                 return;
            }
            
            $response=trim($response);
            if(strripos($response, 'success')===false&&strripos($response, 'ok')===false){
                //去掉多余字符串
                $posi = strpos($response, '{');
                $response = substr($response, $posi);
                
                $result = json_decode($response,true);
                if(!$result||!isset($result['hash'])){
                    $logger->ERROR("appid:{$order->appid},orderid:{$order->id},errmsg:invalid hash callback,details:$response");
                    
                    return;
                }
                
                if($result['hash']!=$this->generate_xh_hash($result, $order->appkey)){
                    $logger->ERROR("appid:{$order->appid},orderid:{$order->id},errmsg:invalid hash,details:$response");
                    return;
                }
                
                if(!isset($result['action'])||strtolower(trim($result['action']))!='success'){
                    $logger->ERROR("appid:{$order->appid},orderid:{$order->id},errmsg:invalid action,details:$response");
                    return;
                }
            }
            

            $success = self::$SUCCESS;
            $wpdb->query(
                "update `order` o
                 set o.check_callback_time=$success
                 where o.id={$order->id};");
             
            if(!empty($wpdb->last_error)){
                $logger->ERROR($wpdb->last_error);
                 return;
            }

            return;
        } catch (Exception $e) {
            $logger = new XH_Log();
            $errcode =intval($e->getCode());
            $logger->ERROR("appid:{$order->appid},orderid:{$order->id},errcode:{$errcode},errmsg:{$e->getMessage()}");
            
            $close_service = false;
            switch($errcode){
                /*
                 521 Web Server Is Down
                 The origin server has refused the connection from CloudFlare.
                */
                case 521:
                    $close_service=true;
                    break;
                    
            }
            
            
            if($close_service){
                $success = self::$FAIL;
                
               try {
                   $wpdb->query(
                       "update `order` o
                       set o.check_callback_time=$success
                       where o.id={$order->id};");
                    
                   if(!empty($wpdb->last_error)){
                       $logger->ERROR($wpdb->last_error);
                       return;
                   }
               } catch (Exception $e) {
                   $logger->ERROR($e->getMessage());
                   //ignore...
               }
                
               return;
            }
        }
	}
	
	public function generate_xh_hash_string($app,array $data){
	    if(!$app){
	        return null;
	    }
	    $data['nonce_str']=str_shuffle(time());
	    $data['time']=time();
	    $data['appid']=$app->id;
	    $data['hash']=$this->generate_xh_hash($data, $app->appkey);
	    return $data;
	}
	
	protected function __generate_xh_hash(array $datas,$hashkey){
	    ksort($datas);
	    reset($datas);
	     
	    $pre =array();
	    foreach ($datas as $key => $data){
	        
	        if($key=='hash'){
	            continue;
	        }
	         
	        $pre[$key]=$data;
	    }
	     
	    $arg  = '';
	    $qty = count($pre);
	    $index=0;
	     
	    foreach ($pre as $key=>$val){
	        $arg.="$key=$val";
	        if($index++<($qty-1)){
	            $arg.="&";
	        }
	    }
	     
	    return md5($arg.$hashkey);
	}
	protected function generate_xh_hash(array $datas,$hashkey){
	    ksort($datas);
	    reset($datas);
	    
	    $pre =array();
	    foreach ($datas as $key => $data){
	        if(is_null($data)||$data===''){
	            continue;
	        }
	        if($key=='hash'){
	            continue;
	        }
	        
	        $pre[$key]=$data;
	    }
	    
	    $arg  = '';
	    $qty = count($pre);
	    $index=0;
	    
	    foreach ($pre as $key=>$val){
	        $arg.="$key=$val";
	        if($index++<($qty-1)){
	            $arg.="&";
	        }
	    }
	    
	    return md5($arg.$hashkey);
	}
	
	
	/**
	 * 验证请求
	 * 
	 * @param array $data
	 * @param boolean $checkip
	 * @param boolean $checkReq
	 * @param int $expire_time
	 * @throws Exception
	 */
	public function authorize($data,$checkipandDomain,$expire_time=10){	    
		if(!$data){
		    throw new Exception('Your request is empty!',400);
		}
		if(!is_array($data)&&is_object($data)){
		    $data = get_object_vars($data);
		}
		
		if(
	        !isset($data['appid'])
	        ||empty($data['appid'])
	        ||!is_numeric($data['appid'])){
	            throw new Exception('未知的APPID!',40029);
		}
		
	    if(!isset($data['hash'])
	        ||empty($data['hash'])
	        
	        ||!isset($data['appid'])
	        ||empty($data['appid'])
	        ||!is_numeric($data['appid'])
	        
	        ||!isset($data['time'])
	        ||!is_numeric($data['time'])
	        ){
	        throw new Exception('invalid http request(缺少参数appid,time,hash或他们的值不合法)!',40029);
	    }
	    
	    //检查请求是否超时
	    $now =time();
	    if($expire_time>0){
    	    if(($now-$expire_time)>$data['time']||$now<$data['time']){
    	        throw new Exception('Your request is timeout!',400);
    	    }
	    }
	   
	    global $wpdb;
	    $appid = absint($data['appid']);
	    //检查appid是否存在
	    $app = $wpdb->get_row(
	        "select a.id,
	                a.appkey,
	                a.domain,
	                a.name,
	                a.member_id,
	                a.channel_type,
	                m.parent_user_id,
	                a.exchange_rate,
	                a.config1,
	                a.status,
                    m.pt_amount,
	                a.parent_exchange_rate
	        from app a
	        inner join member m on m.id = a.member_id
	        where a.id={$appid}
	              and m.status='P'
	        limit 1;");

	    if(!$app){
	        $logger = new XH_Log();
	        $logger->DEBUG('invalid website app info.detail info:'.print_r($data,true));
	        throw new Exception('请检查应用APPID',40029);
	    }
	    
	    if($app->status=='disabled'){
	        $logger = new XH_Log();
	        $logger->DEBUG('invalid website app info.detail info:'.print_r($data,true));
	        throw new Exception('您的应用已被冻结，请联系管理员解禁！',40029);
	    }

	    if($app->status!='publish'){
	        $logger = new XH_Log();
	        $logger->DEBUG('invalid website app info.detail info:'.print_r($data,true));
	        throw new Exception('您的应用未发布！',40029);
	    }
	    
       if($app->pt_amount<=0){
	        throw new Exception('您已欠费，请充值后继续使用当前支付通道！',40029);
       }
      
	    $hash = $this->generate_xh_hash($data, $app->appkey);
	    if($hash!=$data['hash']){
	        if($data['hash']!=$this->__generate_xh_hash($data, $app->appkey)){
    	        $logger = new XH_Log();
    	        $logger->DEBUG('invalid website sign.detail info:'.print_r($data,true).",sign:{$hash}");
    	        throw new Exception('错误的签名！请核对appid,appsecret',40029);
	        }
	    }
	  
	   return array(
           'app'=>$app,
           'data'=>$data
	   );
	}
}