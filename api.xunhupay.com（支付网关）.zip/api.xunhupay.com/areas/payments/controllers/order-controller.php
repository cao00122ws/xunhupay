<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';
class Order_Controller extends Web_Abstract_Controller{
    public function add_log(){
    	global $wpdb;
        $wpdb->insert("log",array(
            'msg'=>isset($_REQUEST['msg'])?$_REQUEST['msg']:null,
            'created_time'=>date('Y-m-d H:i:s',current_time( 'timestamp' ))
        ));
       return $this->json_result(XH_Error::success());
    }
  
    public function query(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,5*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->json_result(XH_Error::error_custom('Order is expired!'));
        }
    
        $order =$wpdb->get_row($wpdb->prepare(
            "select id as order_id,
                    total_amount,
                    title,
                    status,
                    payment_method
            from `order` o
            where o.id=%s
                  and o.appid=%s
            limit 1;", $data['id'],$data['appid']));
    
        if(!$order){
           return $this->json_result(XH_Error::error_custom('Order is expired!'));
        }
        
        return $this->json_result(XH_Error::success($order));
    }
  
    public function query_new(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,30*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->jsonp_result(XH_Error::error_custom('Order is expired!'));
        }
    
        $order =$wpdb->get_row($wpdb->prepare(
            "select id as order_id,
                    total_amount,
                    title,
                    status,
                    payment_method,
                    o.pay_url
            from `order` o
            where o.id=%s
                  and o.appid=%s
            limit 1;", $data['id'],$data['appid']));
    
        if(!$order){
           return $this->jsonp_result(XH_Error::error_custom('Order is expired!'));
        }
        
        return $this->jsonp_result(XH_Error::success($order));
    }
  
   public function query_new_c(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'open_order_id'=>isset($_REQUEST['open_order_id'])?$_REQUEST['open_order_id']:'',
            'out_trade_order'=>isset($_REQUEST['out_trade_order'])?$_REQUEST['out_trade_order']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
         if(empty( $data['open_order_id'])&&empty( $data['out_trade_order'])){
         	 return $this->json_result(XH_Error::error_custom('Invalid open_order_id or out_trade_order!'));
         }
     
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,0);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->json_result(XH_Error::error_custom('Order is expired!'));
        }
    
     	if(!empty( $data['open_order_id'])){
          $order =$wpdb->get_row($wpdb->prepare(
              "select o.id as open_order_id,
                      o.total_amount,
                      o.title,
                      o.status,
                      o.transaction_id,
                      o.order_date,
                      o.order_paid_date as paid_date,
                      o.payment_method,
                      o.pay_url,
                      o.trade_order_id as out_trade_order
              from `order` o
              where o.id=%s
                    and o.appid=%s
              limit 1;", $data['open_order_id'],$data['appid']));
        }else{
        	 $order =$wpdb->get_row($wpdb->prepare(
                "select o.id as open_order_id,
                        o.total_amount,
                        o.title,
                        o.status,
                        o.payment_method,
                        o.transaction_id,
                        o.order_paid_date as paid_date,
                        o.pay_url,
                        o.trade_order_id as out_trade_order
                from `order` o
                where o.trade_order_id=%s
                      and o.appid=%s
                      and o.status='OD'
                order by o.id desc
                limit 1;", $data['out_trade_order'],$data['appid']));
         
             if(!$order){
                 $order =$wpdb->get_row($wpdb->prepare(
                  "select o.id as open_order_id,
                          o.total_amount,
                          o.title,
                          o.status,
                          o.payment_method,
                          o.transaction_id,
                          o.order_date,
                          o.order_paid_date as paid_date,
                          o.pay_url,
                        o.trade_order_id as out_trade_order
                  from `order` o
                  where o.trade_order_id=%s
                        and o.appid=%s
                  order by o.id desc
                  limit 1;", $data['out_trade_order'],$data['appid']));
             }
        }
     
        if(!$order){
           return $this->json_result(XH_Error::error_custom('Order is not found!'));
        }
        
        return $this->json_result(XH_Error::success($order));
    }
  
    public function query_new_c_list(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'skip'=>isset($_REQUEST['skip'])?$_REQUEST['skip']:'0',
            'take'=>isset($_REQUEST['take'])?$_REQUEST['take']:'20',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
          	'start'=>isset($_REQUEST['start'])&&!empty($_REQUEST['start'])?date('Y-m-d H:i',strtotime($_REQUEST['start'])):'',
            'end'=>isset($_REQUEST['end'])&&!empty($_REQUEST['end'])?date('Y-m-d H:i',strtotime($_REQUEST['end'])):'',
            'status'=>isset($_REQUEST['status'])?$_REQUEST['status']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
      
      if(!empty($data['status'])&&!in_array($data['status'],array('WP','OD','CD'))){
      		$data['status'] = '';
      }
    
       $data['skip'] = absint( $data['skip']);
       $data['take'] = absint( $data['take']);
      if($data['take']>1000){$data['take']=1000;}
     
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,0);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->json_result(XH_Error::error_custom('request is expired!'));
        }
    
     	 $query =$wpdb->get_row($wpdb->prepare(
              "select count(o.id) as qty,
              		  sum(o.total_amount) as total
              from `order` o
              where  o.appid=%s
              		".($data['start']?" and o.order_date>='{$data['start']}'":"")."
                    ".($data['end']?" and o.order_date<='{$data['end']}'":"")."
                    ".($data['status']?" and o.status='{$data['status']}'":"")
           , $data['appid']));
    
        $orders =$wpdb->get_results($wpdb->prepare(
              "select o.id as open_order_id,
                      o.total_amount,
                      o.title,
                      o.status,
                      o.order_date,
                      o.order_paid_date as paid_date,
                      o.payment_method,
                      o.transaction_id,
                      o.pay_url,
                      o.trade_order_id as out_trade_order
              from `order` o
              where  o.appid=%s
              		".($data['start']?" and o.order_date>='{$data['start']}'":"")."
                    ".($data['end']?" and o.order_date<='{$data['end']}'":"")."
                    ".($data['status']?" and o.status='{$data['status']}'":"")."
              order by o.id asc
              limit {$data['skip']},{$data['take']};",$data['appid']));
        
        
        return $this->json_result(XH_Error::success(array(
        	'total_qty'=>$query->qty,
          	'total_amount'=>$query->total,
            'items'=>$orders
        )));
    }
  
  
}