<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';
class Alipay_Controller extends Web_Abstract_Controller{
    public function index(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
             return $this->error_result('您请求的支付链接已失效！');
        }
        
        try {
            $app->config1 = $this->refresh_auth_token($app);
        } catch (Exception $e) {
            $logger = new XH_Log('payment');
            $logger->ERROR($e->getMessage().print_r( $data,true));
           if($e->getCode()==40004){
           	 	return $this->error_result('支付宝授权已失效，请联系平台重新绑定！');
           }
            return $this->error_result($e->getMessage());
        }
        
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.total_amount,
                    o.title,
                    o.status,
                    o.payment_method,
                    o.ip,
                    o.pay_url,
                    m.wechat as member_wechat
            from `order` o
            inner join app p on p.id = o.appid
            inner join member m on m.id = p.member_id
            where o.id={$id}
                  and o.appid={$app->id}
            limit 1;");
        if(!$order){
             return $this->error_result('您请求的支付链接已失效！');
        }
        
        $order->member_wechat = $order->member_wechat?json_decode($order->member_wechat,true):null;
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $Url->action('return_url','alipay','payments',$this->generate_xh_hash_string($app, array(
                'id'=>$order->id
        )));
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
        
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
        if(!XH_Common::isWebApp()){
            return $this->view_result('qrcode');
        }else{
            return $this->view_result('jsapi');
        }
    }
  
   public function query($id){
        
     
     
        global $wpdb,$ViewBag;
        $orders =  $wpdb->get_results("select o.id,
                        o.total_amount,
                        o.title,
                        o.status,
                        o.payment_method,
                        o.ip,
                        o.pay_url,
                        m.wechat as member_wechat,
                        p.config1
                from `order` o
                inner join app p on p.id = o.appid
                inner join member m on m.id = p.member_id
                where o.status='OD'
                      and o.payment_method='alipay'"
         );
       foreach( $orders  as $order){
            $ali_set = XH_Data_Helper::get_option('setting_alipay_mch', 'common');
            $ali_appid = XH_Common::get($ali_set, 'alipay_appid');
            $alipay_mchid= XH_Common::get($ali_set, 'alipay_mchid');

            $privateKey = XH_Common::get($ali_set, 'alipay_privateKey');
            $publicKey = XH_Common::get($ali_set, 'alipay_publicKey');

            $order->config1 = json_decode($order->config1,true);
            $store_id = $order->config1&&isset($order->config1['store_id'])?$order->config1['store_id']:null;
            $app_auth_token = $order->config1&&isset($order->config1['app_auth_token'])?$order->config1['app_auth_token']:null;
            if(empty($app_auth_token)){
                $ViewBag->set('error', '支付宝未授权！');
                require_once ABSPATH.'/views/shared/_die.phtml' ;
                exit;
            }

            require_once ABSPATH.'infrastructure/lib/aop/AopClient.php';
            require_once ABSPATH.'infrastructure/lib/aop/SignData.php';
            require_once ABSPATH.'infrastructure/lib/aop/request/AlipayOpenAuthTokenAppRequest.php';
            require_once ABSPATH.'infrastructure/lib/aop/request/AlipayTradeQueryRequest.php';
            $res = array(
                'out_trade_no'=>$order->id,
                'extend_params'=>['sys_service_provider_id'=>$alipay_mchid]
            );
            if($store_id){
                $res['alipay_store_id'] = $store_id;
            }

            $aop = new AopClient ();
            $aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
            $aop->appId = $ali_appid;
            $aop->rsaPrivateKey = $privateKey;
            $aop->alipayrsaPublicKey=$publicKey;
            $aop->apiVersion = '1.0';
            $aop->signType = 'RSA2';
            $aop->postCharset='UTF-8';
            $aop->format='json';
            $request = new AlipayTradeQueryRequest ();

            $request->setBizContent(json_encode($res));
            $result = $aop->execute ($request,null,$app_auth_token);
            $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
            $resultCode = $result->$responseNode->code;
         
         	 if($resultCode != 10000){
             	$wpdb->update('order',array(
                	'bad'=>1
                ),array(
                	'id'=>$order->id
                ));
             }
         
         	sleep(2);
       }
    }
  
    public function refresh_auth_token($app,$focus=false){
        $config1 = $app->config1&&is_array($app->config1)?$app->config1:null;
        if(!$config1){
        	 $config1 = $app->config1?json_decode($app->config1,true):null;
        }
        if(!$config1||!is_array($config1)){
            throw new Exception('应用配置异常！'.print_r($app,true));
        }
        
        if(!isset($config1['app_refresh_token'])||empty($config1['app_refresh_token'])){
            throw new Exception('应用未授权签约！');
        }
        
        if((time()-$config1['app_auth_token_expired'])<0&&!$focus){
           return $config1;
        }
        
        //超过330天
        if((time()-$config1['app_auth_token_expired'])>300*24*60*60){
            throw new Exception('300天内未有订单记录,支付宝授权已回收，请联系管理员复审！');
        }
        
        $ali_set =XH_Data_Helper::get_option('setting_alipay_mch', 'common');
        $appid = XH_Common::get($ali_set, 'alipay_appid');
        $privateKey = XH_Common::get($ali_set, 'alipay_privateKey');
        $publicKey = XH_Common::get($ali_set, 'alipay_publicKey');
         
        require_once ABSPATH.'infrastructure/lib/aop/AopClient.php';
        require_once ABSPATH.'infrastructure/lib/aop/SignData.php';
        require_once ABSPATH.'infrastructure/lib/aop/request/AlipayOpenAuthTokenAppRequest.php';
         
        $aop = new AopClient ();
        $aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
        $aop->appId = $appid;
        $aop->rsaPrivateKey = $privateKey;
        $aop->alipayrsaPublicKey = $publicKey;
        $aop->apiVersion = '1.0';
        $aop->signType = 'RSA2';
        $aop->postCharset='UTF-8';
        $aop->format='json';
        $request = new AlipayOpenAuthTokenAppRequest ();
        $request->setBizContent(json_encode([
            'grant_type'=>'refresh_token',
            'refresh_token'=>$config1['app_refresh_token']
        ]));
        
        $result = $aop->execute ($request);
        $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
        if($result->{$responseNode}->code != 10000){
           if($result->{$responseNode}->code==40004){
           		global $wpdb;
             	$remark = array(
                	"error"=>array(
                    	date_i18n('Y-m-d H:i')=>"授权失败:errcode:{$result->{$responseNode}->code} errmsg:{$result->{$responseNode}->msg},{$result->{$responseNode}->sub_msg} "
                    )
                );
                $wpdb->update('app', array(
                    'status'=>'exception',
                  	'remark'=>json_encode($remark)
                ), array(
                    'id'=>$app->id
                ));
             
                $option = XH_Data_Helper::get_option('setting_base','common');
                $site_admin_emails = explode(';', XH_Common::get($option,'site_admin_emails'));

                try {
                    require_once ABSPATH.'infrastructure/lib/mail/class-xh-mail.php';
                    $mailer = new XH_Mail();
                    $mailer->mail($site_admin_emails, "【虎皮椒】支付宝授权失效","店铺:{$app->name} ,域名:{$app->domain}，无法继续授权，请联系用户重新授权");
                } catch (Exception $e) {
                    $logger = new XH_Log();
                    $logger->ERROR($e->getMessage());
                    return parent::json_result(XH_Error::error_custom('邮件发送失败，请重试！'));
                }

           }
          
            throw new Exception("授权失败:errcode:{$result->{$responseNode}->code} errmsg:{$result->{$responseNode}->msg},{$result->{$responseNode}->sub_msg} ",$result->{$responseNode}->code);
        }
        
        $config1['app_auth_token'] = $result->{$responseNode}->app_auth_token;
        $config1['app_refresh_token'] = $result->{$responseNode}->app_refresh_token;
        $config1['app_auth_token_expired'] = time()+60*60*24*7;
        global $wpdb;
        $wpdb->update('app', array(
            'config1'=>json_encode($config1)
        ), array(
            'id'=>$app->id
        ));
        
        if (! empty ( $wpdb->last_error )) {
            $logger = new XH_Log ( 'member' );
            $logger->DEBUG ( $wpdb->last_error );
           throw new Exception('授权失败:系统异常，请刷新页面后重试！');
        }
        
        return $config1;
    }
    
    public function qrcode(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
             return $this->error_result('您请求的支付链接已失效！');
        }
        try {
            $app->config1 = $this->refresh_auth_token($app);
        } catch (Exception $e) {
           $logger = new XH_Log('payment');
            $logger->ERROR($e->getMessage().print_r( $data,true));
           if($e->getCode()==40004){
           	 return $this->error_result('支付宝授权已失效，请联系平台重新绑定！');
           }
            return $this->error_result($e->getMessage());
        }
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.total_amount,
                    o.title,
                    o.status,
                    o.payment_method,
                    o.ip,
                    o.pay_url
            from `order` o
            where o.id={$id}
                  and o.appid={$app->id}
            limit 1;");
        if(!$order){
             return $this->error_result('您请求的支付链接已失效！');
        }
        
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $Url->action('return_url','alipay','payments',$this->generate_xh_hash_string($app, array(
                'id'=>$order->id
        )));
        
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
        
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
      
        $order = $ViewBag->get('order');
        $app = $ViewBag->get('app');
        $that = $ViewBag->get('that');
        $return_url = $ViewBag->get('return_url');
        $query_url = $ViewBag->get('query_url');
        $callback_url = $ViewBag->get('callback_url');
        $now = current_time( 'timestamp' );
        $startTime = date('YmdHis',$now );
        $expiredTime = date('YmdHis',$now+25*60);
        
        $ali_set = XH_Data_Helper::get_option('setting_alipay_mch', 'common');
        $ali_appid = XH_Common::get($ali_set, 'alipay_appid');
        $alipay_mchid= XH_Common::get($ali_set, 'alipay_mchid');
        	
        $privateKey = XH_Common::get($ali_set, 'alipay_privateKey');
        $publicKey = XH_Common::get($ali_set, 'alipay_publicKey');
        
        $store_id = $app->config1&&isset($app->config1['store_id'])?$app->config1['store_id']:null;
        $app_auth_token = $app->config1&&isset($app->config1['app_auth_token'])?$app->config1['app_auth_token']:null;
        if(empty($app_auth_token)){
            $ViewBag->set('error', '支付宝未授权！');
            require_once ABSPATH.'/views/shared/_die.phtml' ;
            exit;
        }
        	
        require_once ABSPATH.'infrastructure/lib/aop/AopClient.php';
        require_once ABSPATH.'infrastructure/lib/aop/SignData.php';
        require_once ABSPATH.'infrastructure/lib/aop/request/AlipayOpenAuthTokenAppRequest.php';
        require_once ABSPATH.'infrastructure/lib/aop/request/AlipayTradePrecreateRequest.php';
        
        $pay_url = $order->pay_url;
        if(empty($pay_url)){
            $res = array(
                'out_trade_no'=>$order->id,
                'total_amount'=>round($order->total_amount,2),
                'subject'=>"#{$order->id}",
                'store_id'=>"hpj-{$app->id}",
                'extend_params'=>['sys_service_provider_id'=>$alipay_mchid]
            );
            if($store_id){
                $res['alipay_store_id'] = $store_id;
            }
            try{
                $aop = new AopClient ();
                $aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
                $aop->appId = $ali_appid;
                $aop->rsaPrivateKey = $privateKey;
                $aop->alipayrsaPublicKey=$publicKey;
                $aop->apiVersion = '1.0';
                $aop->signType = 'RSA2';
                $aop->postCharset='UTF-8';
                $aop->format='json';
                $request = new AlipayTradePrecreateRequest ();
                $request->setNotifyUrl($Url->action('notify','alipay','payments'));
                $request->setBizContent(json_encode($res));
                $result = $aop->execute ($request,null,$app_auth_token);
                $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
                $resultCode = $result->$responseNode->code;
                
                if($resultCode != 10000){
                    if(!isset($result->$responseNode->sub_msg)){$result->$responseNode->sub_msg='';}
                    throw new Exception("errcode:{$resultCode},errmsg:{$result->$responseNode->msg}，detail:{$result->$responseNode->sub_msg}",$resultCode); 
                } 
                
                $pay_url=$result->$responseNode->qr_code;
                global $wpdb;
                $wpdb->update('order', array(
                  'pay_url'=>$pay_url
                ), array(
                  'id'=>$order->id
                ));
                
            }catch (Exception $e){
              if($e->getCode()==20001){
                    try{
                        $that->refresh_auth_token($app,true);
                    }catch (Exception $e){
                        $logger = new XH_Log('payment');
                         $logger->ERROR($e->getMessage().print_r($order,true));
                        if($e->getCode()==40004){
                             $ViewBag->set('error','支付宝授权已失效，请联系平台重新绑定！');
                             require_once ABSPATH.'/views/shared/_die.phtml' ;
                        }

                          $ViewBag->set('error', '支付渠道异常，请重试！');
                          require_once ABSPATH.'/views/shared/_die.phtml' ;
                          exit;
                    }
                }
                $logger = new XH_Log('payment');
                $logger->ERROR($e->getMessage());
                $ViewBag->set('error', '支付时发生不可预测的错误，请重试！');
                require_once ABSPATH.'/views/shared/_die.phtml' ;
                exit;
            }
        }

        $pay_url = $Url->action('qrcode','plugins','',$that->generate_xh_hash_string($app, array(
            'data'=>base64_encode($pay_url)
        )));
      
      return $this->redirect_url($pay_url);
    }
    
    public function return_url(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->error_result('您请求的支付链接已失效！');
        }
        
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.status,
                    o.return_url,
                    o.ip,
                    o.trade_order_id,
                    o.total_amount,
                    o.plugins
            from `order` o
            where o.id={$id}
            and o.appid={$app->id}
            limit 1;");
        if(!$order){
            return $this->error_result('您请求的支付链接已失效！');
        }
        
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $order->return_url;
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
        
        $ali_set = XH_Data_Helper::get_option('setting_alipay_mch', 'common');
        $ali_appid = XH_Common::get($ali_set, 'alipay_appid');
        $alipay_mchid= XH_Common::get($ali_set, 'alipay_mchid');
         
        $privateKey = XH_Common::get($ali_set, 'alipay_privateKey');
        $publicKey = XH_Common::get($ali_set, 'alipay_publicKey');
        try { 
            require_once ABSPATH.'infrastructure/lib/aop/AopClient.php';
            require_once ABSPATH.'infrastructure/lib/aop/SignData.php';
            require_once ABSPATH.'infrastructure/lib/aop/request/AlipayOpenAuthTokenAppRequest.php';
            require_once ABSPATH.'infrastructure/lib/aop/request/AlipayTradeQueryRequest.php';
            $aop = new AopClient ();
            $aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
            $aop->appId = $ali_appid;
            $aop->rsaPrivateKey = $privateKey;
            $aop->alipayrsaPublicKey=$publicKey;
            $aop->apiVersion = '1.0';
            $aop->signType = 'RSA2';
            $aop->postCharset='UTF-8';
            $aop->format='json';
            $request = new AlipayTradeQueryRequest ();
            $request->setBizContent(
                json_encode(array(
                    'out_trade_no'=>$order->id

            )));
            $result = $aop->execute ( $request); 
            
            $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
            $resultCode = $result->$responseNode->code;
            if($resultCode == 10000&& in_array($result->$responseNode->trade_status, array('TRADE_SUCCESS','TRADE_FINISHED'))){
                $this->notify_order($order->id,$result->$responseNode->trade_no);
                return $this->redirect_url($return_url);
            } 
            
            return $this->error_result('订单未支付！');
        } catch (Exception $e) {
            $logger = new XH_Log();
            $logger->ERROR($e->getMessage());
            return $this->error_result('系统内部异常，请刷新重试！');
        } 
    }
    
    private function validate_sign(array $params,$publickey){
        $sign = $params['sign'];
        $signType = $params['sign_type'];
        unset($params['sign_type']);
        unset($params['sign']);
    
        $args = '';
        $i = 0;
        ksort($params);
        reset($params);
        foreach ($params as $k => $v) {
            if (!is_null($v)&&$v!=='') {
                if ($i == 0) {
                    $args .= "{$k}={$v}";
                } else {
                    $args .= "&{$k}={$v}" ;
                }
                $i++;
            }
        }
        unset ($k, $v);
        if(strpos($publickey, '-----BEGIN PUBLIC KEY-----')===false)
            $publickey = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($publickey, 64, "\n", true) . "\n-----END PUBLIC KEY-----";
    
        return (bool)openssl_verify($args, base64_decode($sign), $publickey, version_compare(PHP_VERSION,'5.4.0', '<') ? SHA256 : OPENSSL_ALGO_SHA256);
    }
    public function notify(){
        $request = stripslashes_deep($_POST);
        $ali_set = XH_Data_Helper::get_option('setting_alipay_mch', 'common');
        $ali_appid = XH_Common::get($ali_set, 'alipay_appid');
        $alipay_mchid= XH_Common::get($ali_set, 'alipay_mchid');
        
        $privateKey = XH_Common::get($ali_set, 'alipay_privateKey');
        $publicKey = XH_Common::get($ali_set, 'alipay_publicKey');
        
        if(!$this->validate_sign($request, $publicKey)){
            echo 'invalid sign';
            exit;
        }
      
        $order_id = $request['out_trade_no'];
        $transaction_id = $request["trade_no"];
       
        try {
          	if($request['trade_status']=='TRADE_FINISHED'||$request['trade_status'] =='TRADE_SUCCESS'){
           		 $this->notify_order($order_id,$transaction_id);
            }
            echo 'success';
            exit;
              
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }
}
