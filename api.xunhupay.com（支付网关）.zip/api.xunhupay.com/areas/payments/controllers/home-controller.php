<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';
class Home_Controller extends Web_Abstract_Controller{
    /**
     * pay api
     * @throws Exception
     */
	public function pay(){
	    $app=null;
	    $post_datas =isset($GLOBALS['HTTP_RAW_POST_DATA'])?$GLOBALS['HTTP_RAW_POST_DATA']:'';
		if(empty($post_datas)){
			$post_datas = file_get_contents("php://input");
		};
     
		$data = json_decode($post_datas,true); 
		if(empty($data)){
            $data = stripslashes_deep($_POST);
            if(empty($data)){
              $data = stripslashes_deep($_GET);
            }
          
            if(empty($data)){
               return $this->redirect_url(XH_Web_Config::Rewrite_Url);
            }
		}
		  
	    try {
	        $request = $this->authorize($data,true,-1);
	        $app =$request['app'];
	        $data = $request['data'];
	        global $wpdb;
            if( !isset($data['total_fee'])
                 
                ||!isset($data['trade_order_id'])
                ||empty($data['trade_order_id'])
                 
                ||!isset($data['title'])
                ||empty($data['title'])
                 
                ||!isset($data['notify_url'])
                ||empty($data['notify_url'])){
                    throw new Exception('请检查请求参数(不完整)!',40029);
           }
            
          if(!isset($data['return_url'])||empty($data['return_url'])){
            global $Url;
          	$data['return_url'] = $Url->action('success','home','payments');
          }
          
          if(!isset($data['callback_url'])||empty($data['callback_url'])){
            global $Url;
          	$data['callback_url'] = $Url->action('cancel','home','payments');
          }
          
           $data['total_fee'] =round(floatval($data['total_fee']),2);
           if($data['total_fee'] <=0){
               throw new Exception('订单金额必须大于0！',40027);
           }
           
           $data['exchange_rate']=$app->exchange_rate;
           
           ///////////////////////////////////////
           
           $time_now = current_time( 'timestamp' );
           $now = date('Y-m-d H:i:s',$time_now);
           $order =array(
               'total_amount'=>round(floatval($data['total_fee']),2),
               'payment_method'=>$app->channel_type,
               'appid'=>$app->id,
               'plugins'=>isset($data['plugins'])?$data['plugins']:'',
               'title'=>$data['title'],
               'order_date'=>date('Y-m-d H:i:s',$time_now),
               'status'=>'WP',
               'attach'=>isset($data['attach'])?$data['attach']:'',
               'trade_order_id'=>$data['trade_order_id'],
               'notify_url'=>$data['notify_url'],
               'return_url'=>isset($data['return_url'])?$data['return_url']:'',
               'callback_url'=>isset($data['callback_url'])?$data['callback_url']:''
           );

           $wpdb->insert('order', $order);
           $order_id =$wpdb->insert_id;
           $order['order_id']=$order_id;
           if(!empty($wpdb->last_error)){
               $logger = new XH_Log();
               $logger->ERROR($wpdb->last_error);
               throw new Exception('系统内部错误，请稍候重试！',500);
           }
            
           if($order_id<=0){
               $logger = new XH_Log ( 'member' );
               $logger->DEBUG ( "数据插入时发生不可预测的问题:".print_r($wpdb,true) );
               throw new Exception('系统内部错误，请稍候重试！',500);
           }
  
           $pt_amount = round($order['total_amount']*($app->exchange_rate+$app->parent_exchange_rate),2);
           if($pt_amount<=0){
               $pt_amount=0.01;
           }
           
           $income =array(
               'desc'=>'订单：#'.$order['order_id'],
               'member_id'=>$app->member_id,
               'type'=>'order',
               'order_id'=>$order_id,
               'appid'=>$app->id,
               'pt_amount'=>$pt_amount,
               'amount'=>$order['total_amount'],
               'exchange_rate'=>round($app->exchange_rate,3),
               'created_time'=>date_i18n('Y-m-d H:i:s'),
               'status'=>'A',
               'parent_member_id'=> $app->parent_user_id,
               'parent_exchange_rate'=>round( $app->parent_exchange_rate,3),
               'parent_income'=>round($order['total_amount']* $app->parent_exchange_rate,2)
           );
           
           $wpdb->insert('member_income', $income);          
           if(!empty($wpdb->last_error)){
               $logger = new XH_Log();
               $logger->ERROR($wpdb->last_error);
               throw new Exception('系统内部错误，请稍候重试！',500);
           }

           if($wpdb->insert_id<=0){
               $logger = new XH_Log ( 'member' );
               $logger->DEBUG ( "数据插入时发生不可预测的问题:".print_r($wpdb,true) );
               throw new Exception('系统内部错误，请稍候重试！',500);
           }
          
           return $this->do_pay($app,$order,$data);
	    } catch (Exception $e) {
	        $errcode =$e->getCode();
	        $errmsg =$e->getMessage();
	       
	        $logger = new XH_Log();
	        $logger->ERROR("errcode:{$errcode},errmsg:{$errmsg},details:".print_r($data,true));
	      	if(isset($_REQUEST['redirect'])){
            	return $this->error_result($errmsg);
            }
	        return $this->hash_result($app,$errcode<=0?500:$errcode,$errmsg);
	    }
	}
	public function cancel(){
   		return $this->view_result();
   }
   public function success(){
   		return $this->view_result();
   }
  
	public function callback_url(){
	    global $wpdb,$ViewBag,$Url;
	    
	    $data = array(
	        'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
	        'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
	        'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
	        'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
	        'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
	    );
	    
	    $app =null;
	    try {
	        //链接在5分钟内可无限刷新(订单过期时间为5分钟)
	        $request =$this->authorize($data, false,25*60);
	        $app = $request['app'];
	    } catch (Exception $e) {
	        //这里不写日志，否则日志太多
	        return $this->error_result('您请求的支付链接已失效！');
	    }
	    
	    $id = absint($data['id']);
	    
	    $order =$wpdb->get_row(
	        "select o.id,
        	        o.status,
        	        o.callback_url,
	                o.return_url,
        	        o.ip
	        from `order` o
	        where o.id={$id}
	        and o.appid={$app->id}
	        limit 1;");
	    if(!$order){
	        return $this->error_result('您请求的支付链接已失效！');
	    }
	    
	    $ip = XH_Common::get_client_ip();
	    if(!$order->ip){
	        $wpdb->update('order', array(
	            'ip'=>$ip
	        ), array(
	            'id'=>$order->id
	        ));
	    }else if($order->ip!=$ip){
	        return $this->error_result('检测到您的IP有变更，请重新下单！');
	    }
	    if(empty($order->callback_url)){
	        $order->callback_url =$order->return_url;
	    }
	    return $this->redirect_url($order->callback_url);
	}
	
	
	public function query(){
	    global $wpdb,$ViewBag,$Url;
	
	    $data = array(
	        'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
	        'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
	        'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
	        'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
	        'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
	    );
	
	    $app =null;
	    try {
	        //链接在5分钟内可无限刷新(订单过期时间为5分钟)
	        $request =$this->authorize($data, false,25*60);
	        $app = $request['app'];
	    } catch (Exception $e) {
	       return $this->json_result(array(
	           'isPaid'=>false
	       ));
	    }
	
	    $id = absint($data['id']);
	
	    $order =$wpdb->get_row(
	        "select o.id,
        	        o.status
	        from `order` o
	        where o.id={$id}
	               and o.appid={$app->id}
	        limit 1;");
	    if(!$order){
	       return $this->json_result(array(
	           'isPaid'=>false
	       ));
	    }
	
	   return $this->json_result(array(
	       'isPaid'=>$order->status=='OD'
	   ));
	}
	
	private function do_pay($app,$order,$data){
	    global $wpdb,$Url;
	    
        switch($order['payment_method']){
            case 'wechat':
                if(isset($data['trade_type'])&&$data['trade_type']=='JSAPI'){
                    return $this->wechat_jsapi($app,$order,$data);
                }
                
                if(isset($data['redirect'])){
                    wp_redirect($Url->action('index','wechat','payments',$this->generate_xh_hash_string($app, array(
                        'id'=>$order['order_id']
                    ))));exit;
                }
                
                return $this->hash_result($app, 0, null,array(
                 	'openid'=>$order['order_id'],
                    'url_qrcode'=>$Url->action('qrcode','wechat','payments',$this->generate_xh_hash_string($app, array(
                        'id'=>$order['order_id']
                    ))),
    	            'url'=>$Url->action('index','wechat','payments',$this->generate_xh_hash_string($app, array(
    	                   'id'=>$order['order_id']
    	        )))));
            case 'alipay':
                if(isset($data['redirect'])){
                    wp_redirect($Url->action('index','alipay','payments',$this->generate_xh_hash_string($app, array(
                        'id'=>$order['order_id']
                    ))));exit;
                }
                
                return $this->hash_result($app, 0, null,array(
                    'openid'=>$order['order_id'],
                    'url_qrcode'=>$Url->action('qrcode','alipay','payments',$this->generate_xh_hash_string($app, array(
                        'id'=>$order['order_id']
                    ))),
                    'url'=>$Url->action('index','alipay','payments',$this->generate_xh_hash_string($app, array(
                    'id'=>$order['order_id']
                )))));
             case 'ali':
                if(isset($data['redirect'])){
                    wp_redirect($Url->action('index','ali','payments',$this->generate_xh_hash_string($app, array(
                        'id'=>$order['order_id']
                    ))));exit;
                }
                
                return $this->hash_result($app, 0, null,array(
                    'openid'=>$order['order_id'],
                    'url_qrcode'=>$Url->action('qrcode','ali','payments',$this->generate_xh_hash_string($app, array(
                        'id'=>$order['order_id']
                    ))),
                    'url'=>$Url->action('index','ali','payments',$this->generate_xh_hash_string($app, array(
                    'id'=>$order['order_id']
                )))));
            default:
                throw new Exception('Bad request(Unknow payment)',400);
        }
	}
	
	public function wechat_jsapi($app,$order,$data){
	    $now = current_time( 'timestamp' );
	    $startTime = date('YmdHis',$now );
	    $expiredTime = date('YmdHis',$now+25*60);
	    
	    require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
	    $wechatMchBase = new WechatMchBase();
	    $config1 = $app->config1?json_decode($app->config1,true):null;
	    $sub_mch_id = $config1&&is_array($config1)&&isset($config1['sub_mch_id'])?$config1['sub_mch_id']:null;
	    if(!$sub_mch_id){
	        throw new Exception('商户未签约或签约信息异常！');
	    }
	    
	    global $Url;
        $request = array(
            'appid'=>$wechatMchBase->appid,
            'mch_id'=>$wechatMchBase->mch_id,
            'sub_mch_id'=>$sub_mch_id,
            'body'=>"#{$order['order_id']}",
            'total_fee'=>round($order['total_amount']*100),
            'out_trade_no'=>$order['order_id'],
            'time_start'=>$startTime,
            'time_expire'=>$expiredTime,
            'notify_url'=>$Url->action('notify','wechat','payments'),
            'trade_type'=> 'JSAPI',
            'spbill_create_ip'=>$wechatMchBase->getClientIP(),
            'nonce_str'=>str_shuffle(time())
        );
    
        if(!isset($config1['sub_appid'])||empty($config1['sub_appid'])){
            throw new Exception('商户未绑定appid！');
        }
        
        if(!isset($data['openid'])||empty($data['openid'])){
            throw new Exception('参数缺失：openid！');
        }
        
        $request['sub_appid'] = $config1['sub_appid'];
        $request['sub_openid'] = $data['openid'];
        
        try{
            $wechat_order = $wechatMchBase->generate_wechat_order($request);
            $jsapi = array(
                'timeStamp'=>time(),
                'nonceStr'=>str_shuffle(time()),
                'package'=>"prepay_id={$wechat_order['prepay_id']}",
                'signType'=>'MD5',
                'appId'=>$request['sub_appid']
             );
            
            ksort($jsapi);
            reset($jsapi);
            $str = '';
            foreach ($jsapi as $k => $v){
                if($str){$str.='&';}
                $str.="{$k}={$v}";
            }
        
            $str .= "&key=".$wechatMchBase->sign_key;
            $jsapi['paySign'] =  strtoupper(md5($str));
            
            $map = array(
                'order_id'=>$order['order_id'],
                'time'=>time(),
                'nonce_str'=>substr(str_shuffle(time()), 0,6)

            );
            $map['sign'] = substr(strtolower(md5(http_build_query($map).$wechatMchBase->sign_key)), 4,8);
            
            global $wpdb;
            $wpdb->update('order', array(
                'pay_url'=>json_encode($jsapi)

            ), array(
                'id'=>$order['order_id']

            ));
            
            if(!empty($wpdb->last_error)){
                throw new Exception($wpdb->last_error);
            }
            
            return $this->hash_result($app, 0, null,array(
                'openid'=>$order['order_id'],
                'token'=>join('.', array_values($map)),
                'appid'=>$request['sub_appid'],
                'prepay_id'=>$wechat_order['prepay_id'],
                'jsapi'=>json_encode($jsapi)
            ));
        
        }catch (Exception $e){
            $logger = new XH_Log();
            $logger->ERROR($e->getMessage());
            throw new Exception('支付请求时发生不可预测的错误，请重试！');
        }
	}
}
