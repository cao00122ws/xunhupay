<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';
class Wechat_Controller extends Web_Abstract_Controller{
    public function index(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
             return $this->error_result('您请求的支付链接已失效！');
        }
        
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.total_amount,
                    o.title,
                    o.status,
                    o.payment_method,
                    o.ip,
                    o.pay_url,
                    m.wechat as member_wechat
            from `order` o
            inner join app p on p.id = o.appid
            inner join member m on m.id = p.member_id
            where o.id={$id}
                  and o.appid={$app->id}
            limit 1;");
        if(!$order){
             return $this->error_result('您请求的支付链接已失效！');
        }
        $order->member_wechat = $order->member_wechat?json_decode($order->member_wechat,true):null;
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $Url->action('return_url','wechat','payments',$this->generate_xh_hash_string($app, array(
                'id'=>$order->id
        )));
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
        
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
        

        $ViewBag->set('payqr_url', $Url->action('payqr','wechat','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('payh5_url', $Url->action('payh5','wechat','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('payjs_url', $Url->action('payjs','wechat','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        
        return $this->view_result('index');
    }
  
    public function checktoken(){
        $token = isset($_REQUEST['token'])?$_REQUEST['token']:null;
        $tokens = $token?explode('.', $token):array();
        if(count($tokens)!=4){
             wp_send_json(array(
                 'code'=>'invalid-token',
                 'message'=>'订单支付异常!'

             ));
             exit;
        }
        
        $map = array(
            'order_id'=>absint($tokens[0]),
            'time'=>absint($tokens[1]),
            'nonce_str'=>$tokens[2]
        );
        
        require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
        $wechatMchBase = new WechatMchBase();
        if($tokens[3]!=substr(strtolower(md5(http_build_query($map).$wechatMchBase->sign_key)), 4,8)){
            wp_send_json(array(
                'code'=>'invalid-token',
                'message'=>'订单支付异常!'
            ));
            exit;
        }
        
         if((time()-$map['time'])>60*15){
             wp_send_json(array(
                 'code'=>'invalid-token',
                 'message'=>'订单支付已超时!'
             ));
             exit;
         }
     
        global $wpdb;
        $order =$wpdb->get_row(
            "select o.id,
                o.pay_url,
                o.status,
                o.total_amount,
                m.wechat as member_wechat
            from `order` o
            inner join app p on p.id = o.appid
            inner join member m on m.id = p.member_id
            where o.id={$map['order_id']}
            limit 1;");
        
        if(!$order){
            wp_send_json(array(
                'code'=>'invalid-token',
                'message'=>'订单支付异常!'
            ));
            exit;
        }
        $member_wechat = json_decode($order->member_wechat,true); 
        
        wp_send_json(array(
			'order_id'=>$order->id,
            'total_amount'=>$order->total_amount,
            'headimgurl'=>$member_wechat?$member_wechat['headimgurl']:null,
            'is_paid'=>$order->status=='OD',
            'jsapi'=>json_decode($order->pay_url,true)
        ));
        exit;
    }
    
    public function payqr(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->error_result('您请求的支付链接已失效！');
        }
        
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.total_amount,
                    o.title,
                    o.status,
                    o.payment_method,
                    o.ip,
                    o.pay_url,
                    m.wechat as member_wechat
            from `order` o
            inner join app p on p.id = o.appid
            inner join member m on m.id = p.member_id
            where o.id={$id}
            and o.appid={$app->id}
            limit 1;");
        if(!$order){
            return $this->error_result('您请求的支付链接已失效！');
        }
        $order->member_wechat = $order->member_wechat?json_decode($order->member_wechat,true):null;
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $Url->action('return_url','wechat','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        )));
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
        
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
        return $this->view_result('qrcode');
    }

    public function payh5(){
        global $wpdb,$ViewBag,$Url;
    
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
    
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->error_result('您请求的支付链接已失效！');
        }
    
        $id = absint($data['id']);
    
        $order =$wpdb->get_row(
            "select o.id,
            o.total_amount,
            o.title,
            o.status,
            o.payment_method,
            o.ip,
            o.pay_url,
            m.wechat as member_wechat
            from `order` o
            inner join app p on p.id = o.appid
            inner join member m on m.id = p.member_id
            where o.id={$id}
            and o.appid={$app->id}
            limit 1;");
        if(!$order){
            return $this->error_result('您请求的支付链接已失效！');
        }
        $order->member_wechat = $order->member_wechat?json_decode($order->member_wechat,true):null;
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
    
        $return_url = $Url->action('return_url','wechat','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        )));
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
    
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
    
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
    
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
        return $this->view_result('h5');
    }

    public function payjs(){
        global $wpdb,$ViewBag,$Url;
    
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
    
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->error_result('您请求的支付链接已失效！');
        }
    
        $id = absint($data['id']);
    
        $order =$wpdb->get_row(
            "select o.id,
            o.total_amount,
            o.title,
            o.status,
            o.payment_method,
            o.ip,
            o.pay_url,
            m.wechat as member_wechat
            from `order` o
            inner join app p on p.id = o.appid
            inner join member m on m.id = p.member_id
            where o.id={$id}
            and o.appid={$app->id}
            limit 1;");
        if(!$order){
            return $this->error_result('您请求的支付链接已失效！');
        }
        $order->member_wechat = $order->member_wechat?json_decode($order->member_wechat,true):null;
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
    
        $return_url = $Url->action('return_url','wechat','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        )));
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
    
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
    
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
    
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
        return $this->view_result('jsapi');
    }
    
    public function qrcode(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
             return $this->error_result('您请求的支付链接已失效！');
        }
        
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.total_amount,
                    o.title,
                    o.status,
                    o.payment_method,
                    o.ip,
                    o.pay_url
            from `order` o
            where o.id={$id}
                  and o.appid={$app->id}
            limit 1;");
        if(!$order){
             return $this->error_result('您请求的支付链接已失效！');
        }
        
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $Url->action('return_url','wechat','payments',$this->generate_xh_hash_string($app, array(
                'id'=>$order->id
        )));
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }
        
        $ViewBag->set('return_url', $return_url);
        $ViewBag->set('query_url', $Url->action('query','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('callback_url', $Url->action('callback_url','home','payments',$this->generate_xh_hash_string($app, array(
            'id'=>$order->id
        ))));
        $ViewBag->set('order', $order);
        $ViewBag->set('app', $app);
        $ViewBag->set('that', $this);
      
      
        $order = $ViewBag->get('order');
        $app = $ViewBag->get('app');
        $that = $ViewBag->get('that');
        $return_url = $ViewBag->get('return_url');
        $query_url = $ViewBag->get('query_url');
      
        $now = current_time( 'timestamp' );
        $startTime = date('YmdHis',$now );
        $expiredTime = date('YmdHis',$now+25*60);

        require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
        $wechatMchBase = new WechatMchBase();
        $config1 = $app->config1?json_decode($app->config1,true):null;
        $sub_mch_id = $config1&&is_array($config1)&&isset($config1['sub_mch_id'])?$config1['sub_mch_id']:null;
        if(!$sub_mch_id){
            $ViewBag->set('error', '商户未签约或签约信息异常！');
            require_once ABSPATH.'/views/shared/_die.phtml' ;
            exit;
        }
        $pay_url = $order->pay_url;
        if(empty($pay_url)){
            $request = array(
                'body'=>"#{$order->id}",
                'total_fee'=>round($order->total_amount*100),
                'out_trade_no'=>$order->id,
                'time_start'=>$startTime,
                'time_expire'=>$expiredTime,
                'notify_url'=>$Url->action('notify','wechat','payments'),
                'trade_type'=> 'NATIVE',
                'product_id'=>$order->id,
                'appid'=>$wechatMchBase->appid,
                'mch_id'=>$wechatMchBase->mch_id,
                'sub_mch_id'=>$sub_mch_id,
                'spbill_create_ip'=>$wechatMchBase->getClientIP(),
                'nonce_str'=>str_shuffle(time())
            );

            if(isset($config1['sub_appid'])&&!empty($config1['sub_appid'])){
                $request['sub_appid'] = $config1['sub_appid'];
            }
            
            try{
                $wechat_order = $wechatMchBase->generate_wechat_order($request);
                $pay_url=isset($wechat_order ["code_url"])?$wechat_order ["code_url"]:'';
                global $wpdb;
                $wpdb->update('order', array(
                    'pay_url'=>$pay_url
                ), array(
                    'id'=>$order->id
                ));

            }catch (Exception $e){
                $logger = new XH_Log();
                $logger->ERROR($e->getMessage());
                $ViewBag->set('error', '支付请求时发生不可预测的错误，请重试！');
                require_once ABSPATH.'/views/shared/_die.phtml' ;
                exit;
            }
        }

        $pay_url = $Url->action('qrcode','plugins','',$that->generate_xh_hash_string($app, array(
            'data'=>base64_encode($pay_url)
        )));
      
      return $this->redirect_url($pay_url);
    }
    
    public function account(){
        $request = shortcode_atts(array(
            'uid'=>null,
            'time'=>null,
            'notice_str'=>null,
            'sign'=>null
        ), stripslashes_deep($_REQUEST));
    
        $sign = $request['sign'];
        unset($request['sign']);
        if($sign!=md5(http_build_query($request).AUTH_KEY)){
            return $this->error_result('invalid sign!');
        }
    
        $now = time();
        if(($now-absint($request['time']))>15*60){
            return $this->error_result('请求超时!');
        }
    
        require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
        $wechatMchBase = new WechatMchBase();
        $wechatInfo =$wechatMchBase->get_wechat();
    
        global $wpdb;
        $member_id = absint($request['uid']);
        $member = $wpdb->get_row(
            "select *
            from member where id={$member_id}
            limit 1;");
        if(!$member){
            return $this->error_result('请求数据异常!');
        }
    
        $wpdb->update('member', array(
            'wechat'=>json_encode($wechatInfo)
        ), array(
            'id'=>$member->id
        ));
    
        if(!empty($wpdb->last_error)){
            return $this->error_result('系统内部异常!');
        }
        return $this->success_result('账户绑定成功！');
    }
    
    public function account_pay(){
    	$request = shortcode_atts(array(
    			'uid'=>null,
    			'time'=>null,
    			'notice_str'=>null,
    			'sign'=>null
    	), stripslashes_deep($_REQUEST));
    	
    	$sign = $request['sign'];
    	unset($request['sign']);
    	if($sign!=md5(http_build_query($request).AUTH_KEY)){
    		return $this->error_result('invalid sign!');
    	}
    	
    	$now = time();
    	if(($now-absint($request['time']))>15*60){
    		return $this->error_result('请求超时!');
    	}
    	
    	require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
    	$wechatMchBase = new WechatMchBase();
    	$wechatInfo =$wechatMchBase->get_wechat();
    	
    	global $wpdb;
    	$app_id = absint($request['uid']);
    	$member = $wpdb->get_row(
    		   "select m.id as member_id,
					   a.id as appid,
					   a.config1,
                       a.config
    			from member m
				inner join app a on a.member_id = m.id
    			where a.id={$app_id}
    			limit 1;");
    	if(!$member){
    		return $this->error_result('请求数据异常!');
    	}
    	
    	/*$wpdb->update('member', array(
    			'wechat'=>json_encode($wechatInfo)
    	), array(
    			'id'=>$member->member_id
    	));
    	
    	if(!empty($wpdb->last_error)){
    		return $this->error_result('系统内部异常!');
    	}*/
    	
    	$config1 = $member->config1?json_decode($member->config1,true):null;
    	if(!$config1||!is_array($config1)){$config1=array();}
    	
    	if(isset($config1['app_is_paid'])&&$config1['app_is_paid']){
    		return $this->success_result('授权成功!<p>(请返回电脑，继续执行下一步操作)</p>');
    	}
    	
    	$amount = 68;
        $config = $member->config?json_decode($member->config,true):array();
      if(!$config||!is_array( $config)){
        $config=array();
      }
      
      $config['wechat'] = $wechatInfo;
      $wpdb->update('app',array(
      	'config'=>json_encode($config)
      ),array(
      	'id'=>$app_id
      ));
      if(!empty($wpdb->last_error)){
    		return $this->error_result('系统内部异常!');
    	}
      
      if(isset( $config['price'])&&$config['price']){
       $amount =	$config['price'];
      }
    	$re = array(
    			'member_id'=>$member->member_id,
    			'price'=>$amount,
    			'desc'=>"微信通道申请：应用ID：{$member->appid}￥{$amount}",
    			'time'=>0,
    			're_type'=>'wechat',
    			'payment_method'=> 'wechat' ,
    			'created_time'=>date_i18n('Y-m-d H:i:s'),
    			'status'=>'A'
    	);
    	
    	$order_id=0;
    	try {
    		$wpdb->insert('recharge', $re);
    		if (! empty ( $wpdb->last_error )) {
    			$logger = new XH_Log ( 'member' );
    			$logger->DEBUG ( $wpdb->last_error );
    			return parent::json_result (XH_Error::error_custom( $wpdb->last_error));
    		}
    		
    		if($wpdb->insert_id<=0){
    			$logger = new XH_Log ( 'member' );
    			$logger->DEBUG ( "数据插入时发生不可预测的问题:".print_r($wpdb,true) );
    			return parent::json_result (XH_Error::error_unknow());
    		}
    		
    		$order_id=$wpdb->insert_id;
    	} catch ( Exception $e ) {
    		$logger = new XH_Log ( 'member' );
    		$logger->ERROR ( $e->getMessage () );
    		return parent::json_result (XH_Error::error_custom($e->getMessage ()));
    	}
    	
    	$appid = XH_Web_Config::WECHAT_APPID;
		$appsecret = XH_Web_Config::WECHAT_APPSECRET;
    	$gateway = XH_Web_Config::GATEWAY;
    	$secret = $appsecret;
    	global $Url;
    	
    	$data=array(
    			'version'   => '1.0',//api version
    			'lang'       => 'zh-cn',
    			//账户充值
    			'plugins'   => 'wechat-apply',
    			'appid'     => $appid,
    			'trade_order_id'=> "{$app_id}-{$order_id}",
          		'is_app'=>'Y',
    			'payment'   => 'wechat',
    			'total_fee' => $amount,
    			'title'     => "微信通道申请：应用ID：{$member->appid}￥{$amount}",
    			'time'      => time(),
    			'notify_url'=> $Url->action('wnotify','wechat','payments'),
    			'return_url'=>  $Url->action('wsuccess','wechat','payments'),
    			'callback_url'=>$Url->action('wfail','wechat','payments'),
    			'nonce_str' => str_shuffle(time())
    	);
    	
    	$hashkey          = $secret;
    	$data['hash']     = $this->generate_xh_hash($data,$hashkey);
    	$url              = $gateway;
    	
    	try {
    		$response     = $this->http_post($url, json_encode($data));
    		$result       = $response?json_decode($response,true):null;
    		if(!$result){
    			throw new Exception('Internal server error',500);
    		}
    		
    		$hash         = $this->generate_xh_hash($result,$hashkey);
    		if(!isset( $result['hash'])|| $hash!=$result['hash']){
    			throw new Exception(__('Invalid sign!',XH_Wechat_Payment),40029);
    		}
    		
    		if($result['errcode']!=0){
    			throw new Exception($result['errmsg'],$result['errcode']);
    		}
    		
    		return $this->redirect_url($result['url']);
    		
    	} catch (Exception $e) {
    		$logger = new XH_Log();
    		$logger->ERROR($e->getMessage());
    		return $this->error_result($e->getMessage());
    	}
    }
    
    public function wfail(){
    	return $this->error_result('授权失败：订单未支付!');
    }
    
    public function wsuccess(){
    	return $this->success_result('授权成功!<p>(请返回电脑，继续执行下一步操作)</p>');
    }
    
    public function wnotify(){
    	$data = $_POST;
    	global $wpdb;
    	if(!isset($data['hash'])||!isset($data['trade_order_id'])){
    		return parent::json_result (XH_Error::error_custom('invalid sign'));
    	}
    	
    	$appid = XH_Web_Config::WECHAT_APPID;
		$appsecret = XH_Web_Config::WECHAT_APPSECRET;
    	$gateway = XH_Web_Config::GATEWAY;
    	$secret = $appsecret;
    	$appkey =$secret;
    	$hash =$this->generate_xh_hash($data,$appkey);
    	if($data['hash']!=$hash){
    		return parent::json_result (XH_Error::error_custom('invalid sign'));
    	}
    	
    	$ids = explode('-', $data['trade_order_id']);
    	$app_id = absint($ids[0]);
    	$recharge_id = absint($ids[1]);
    	
    	$app = $wpdb->get_row (
    			"select p.*
    			from app p
    			where p.id={$app_id}
    			limit 1;");
    	$recharge = $wpdb->get_row (
    			"select p.*
    			from recharge p
    			where p.id={$recharge_id}
    			limit 1;");
    	if(!$app){
    		echo 'failed!';
    		exit;
    	}
    	
    	$config1 = $app->config1?json_decode($app->config1,true):null;
    	if(!$config1||!is_array($config1)){
    		$config1 = array();
    	}
    	$config1['app_is_paid'] = true;
    	
    	$wpdb->update('app', array(
    			'config1'=>json_encode($config1)
    	), array(
    			'id'=>$app_id
    	));
    	
    	if (! empty ( $wpdb->last_error )) {
    		$logger = new XH_Log ( 'member' );
    		$logger->DEBUG ( $wpdb->last_error );
    		echo 'fail';
    		exit;
    	}
    	
    	if($recharge){
    		$wpdb->update('recharge', array(
    				'status'=>'P',
    				'transaction_id'=>$data['transaction_id']
    		), array(
    				'status'=>'A',
    				'id'=>$recharge_id
    		));
    		
    		if (! empty ( $wpdb->last_error )) {
    			$logger = new XH_Log ( 'member' );
    			$logger->DEBUG ( $wpdb->last_error );
    			echo 'fail';
    			exit;
    		}
    	}
    	/*
    	$options = XH_Data_Helper::get_option('setting_base', 'common');
    	$admin_email =XH_Common::get($options, 'site_admin_emails','');
    	
    	try {
    		$wpdb->insert('message', array(
    				'content'=>json_encode(array(
    						'type'=>'email',
    						'emails'=>json_encode(explode(';', $admin_email)),
    						'subject'=>"【虎皮椒】微信渠道申请，支付￥{$data['total_fee']}",
    						'content'=>"详细信息：". print_r($data,true)
    				)),
    				'created_time'=>date_i18n('Y-m-d H:i:s'),
    				'status'=>'A'
    		));
    	} catch (Exception $e) {
    		$logger = new XH_Log ( 'member' );
    		$logger->ERROR ( $e->getMessage () );
    	}*/
    	
    	echo 'success';
    	exit;
    }
    
    public function return_url(){
        global $wpdb,$ViewBag,$Url;
        
        $data = array(
            'id'=>isset($_REQUEST['id'])?$_REQUEST['id']:'',
            'appid'=>isset($_REQUEST['appid'])?$_REQUEST['appid']:'',
            'time'=>isset($_REQUEST['time'])?$_REQUEST['time']:'',
            'nonce_str'=>isset($_REQUEST['nonce_str'])?$_REQUEST['nonce_str']:'',
            'hash'=>isset($_REQUEST['hash'])?$_REQUEST['hash']:'',
        );
        
        $app =null;
        try {
            //链接在5分钟内可无限刷新(订单过期时间为5分钟)
            $request =$this->authorize($data, false,25*60);
            $app = $request['app'];
        } catch (Exception $e) {
            //这里不写日志，否则日志太多
            return $this->error_result('您请求的支付链接已失效！');
        }
        
        $id = absint($data['id']);
        
        $order =$wpdb->get_row(
            "select o.id,
                    o.status,
                    o.return_url,
                    o.ip,
                    o.trade_order_id,
                    o.total_amount,
                    o.plugins
            from `order` o
            where o.id={$id}
            and o.appid={$app->id}
            limit 1;");
        if(!$order){
            return $this->error_result('您请求的支付链接已失效！');
        }
        
        $ip = XH_Common::get_client_ip();
        if(!$order->ip){
            $wpdb->update('order', array(
                'ip'=>$ip
            ), array(
                'id'=>$order->id
            ));
        }else if($order->ip!=$ip){
            return $this->error_result('检测到您的IP有变更，请重新下单！');
        }
        
        $return_url = $order->return_url;
        if($order->status=='OD'){
            return $this->redirect_url($return_url);
        }

        $config1 = $app->config1?json_decode($app->config1,true):null;
        $sub_mch_id = $config1&&is_array($config1)&&isset($config1['sub_mch_id'])?$config1['sub_mch_id']:null;
        if(!$sub_mch_id){
            return $this->error_result('商户未签约或签约信息异常！');
        }
        
        require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
        $wechatMchBase = new WechatMchBase();
       
        try {
            $request = array(
                'out_trade_no'=>$order->id,
                'appid'=>$wechatMchBase->appid,
                'sub_mch_id'=>$sub_mch_id,
                'mch_id'=>$wechatMchBase->mch_id,
                'nonce_str'=>str_shuffle(time())
            );
            if(isset($config1['sub_appid'])&&!empty($config1['sub_appid'])){
                $request['sub_appid'] = $config1['sub_appid'];
            }
            $wechat_order = $wechatMchBase->query_wechat_order($request);
       
            if(isset($wechat_order['trade_state'])&&$wechat_order['trade_state']=='SUCCESS'){
                $this->notify_order($order->id,$wechat_order['transaction_id']);
                return $this->redirect_url($return_url);
            }
            return $this->error_result('订单未支付！');
            
        } catch (Exception $e) {
            $logger = new XH_Log();
            $logger->ERROR($e->getMessage());
            return $this->error_result('系统内部异常，请刷新重试！');
        }
    }
    
    public function notify(){
        require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
        $wechatMchBase = new WechatMchBase();
        $xml =isset($GLOBALS['HTTP_RAW_POST_DATA'])?$GLOBALS['HTTP_RAW_POST_DATA']:'';
        if(empty($xml)){
            $xml = file_get_contents("php://input");
        }
        
        if(empty($xml)){
            return $this->error_result('invalid request!');
        }
        
        $response =$wechatMchBase->xml_to_obj($xml);
        if(!$response){
            return $this->error_result('invalid request!');
        }
       
        if($response['sign'] !== $wechatMchBase->generate_sign($response)){
            return $this->error_result('invalid sign!');
        }
        
        $order_id = isset($response['out_trade_no'])?$response['out_trade_no']:null;
        $transaction_id = $response["transaction_id"];
        
        try {
            $this->notify_order($order_id,$transaction_id);
            echo '<xml>
                  <return_code><![CDATA[SUCCESS]]></return_code>
                  <return_msg><![CDATA[OK]]></return_msg>
                </xml>';
            exit;
              
        } catch (Exception $e) {
            echo '<xml>
              <return_code><![CDATA[SUCCESS]]></return_code>
              <return_msg><![CDATA[OK]]></return_msg>
            </xml>';
            exit;
        }
    }
}
