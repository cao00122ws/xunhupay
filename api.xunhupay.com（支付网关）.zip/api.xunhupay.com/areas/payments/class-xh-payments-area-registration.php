<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
class XH_Payments_Area_Registration extends XH_Abstract_Area_Registration {
	/**
	 * 获取area
	 */
	public function get_area() {
		return 'payments';
	}
	
	/**
	 * 注册路由
	 * 
	 * @param XH_Route_Conllection $routes        	
	 */
	public function register_routes($routes) {
	    $routes->map_route('payment/wechat/token.html', array(
	        'action'=>'checktoken',
	        'controller'=>'wechat'
	    ));
	    
		$routes->map_route('payment/do.html', array(
			'action'=>'pay',
			'controller'=>'home'
		));
		
		$routes->map_route('account/paywx.html', array(
				'action'=>'account_pay',
				'controller'=>'wechat'
		));
		
		$routes->map_route('account/bindwx.html', array(
		    'action'=>'account',
		    'controller'=>'wechat'
		));
		
        $routes->map_route('payment/query.html', array(
		    'action'=>'query_new_c',
		    'controller'=>'order'
		));
      
        $routes->map_route('payment/querylist.html', array(
		    'action'=>'query_new_c_list',
		    'controller'=>'order'
		));
      
		$routes->map_route('payment/queryorder.html', array(
		    'action'=>'query',
		    'controller'=>'order'
		));
		
		$routes->map_route('service/order/check/paid.html', array(
		    'action'=>'sync_order_paid',
		    'controller'=>'service'
		));
		
		$routes->map_route('service/order/check/callback.html', array(
		    'action'=>'sync_order_callback',
		    'controller'=>'service'
		));
	}
}