<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';
require_once ABSPATH.'infrastructure/lib/mail/class-xh-mail.php';

class Msg_Controller extends Web_Abstract_Controller{
   
  
    public function index(){
        $now =date_i18n ( 'Y-m-d H:i:s' );
        global $wpdb;
        $service_id = XH_Common::guid();
        
        $wpdb->query(
            "update message m
             set m.service_id='$service_id'
             where m.status='A' and m.service_id is null
             limit 10;");
        if(!empty($wpdb->last_error)){
            $logger =new xh_Log('service');
            $logger ->ERROR($wpdb->last_error);
            return $this->content_result($wpdb->last_error);
        }
        
        $messages =$wpdb->get_results(
            "select *
            from message
            where status='A'
                  and service_id='$service_id'
            limit 10;");
        if(!$messages){
            return $this->content_result('success');
        }
        
        $mailer = new XH_Mail();
        
      require_once ABSPATH.'/infrastructure/wechatMchApi/base.php';
      $wechatMchBase = new WechatMchBase();
      
        foreach ($messages as $message){
            try {
                $result =$wpdb->query(
                    "update message m
                    set m.status='P',
                        m.sended_time='$now'
                    where m.status='A'
                          and m.id={$message->id}
                    limit 1;");
                
                if(!empty($wpdb->last_error)){
                    throw new Exception($wpdb->last_error);    
                }
                
                if(!$result){
                    continue;
                }
                
                $content = json_decode($message->content,false);
                if(!$content||empty($content->type)){
                    throw new Exception('invalid message,details:'.print_r($message,true));
                }
                
                switch ($content->type){
                    case 'wechat':
                    	if($content->openid){
                          $wechatMchBase->send_template_msg(
                               $content->openid,
                               $content->templete_id,
                               $content->url,
                               json_decode($content->content,true)
                           );
                        }
                        break;
                    case 'email':
                        $mailer->mail(json_decode($content->emails), $content->subject,$content->content,'Content-type: text/html');
                        break;
                }
            } catch (Exception $e) {
                $logger = new XH_Log();
                $logger->ERROR("message({$message->id}) sended unknow error,errors:".$e->getMessage());
                
               try {
                   $wpdb->query($wpdb->prepare(
                       "update message m
                        set m.sended_result=%s,
                            m.status='F'
                        where m.status='P'
                              and m.id={$message->id}
                       limit 1;", str_replace("'", '', $e->getMessage())) );
               } catch (Exception $e) {
                   $logger = new XH_Log();
                   $logger->ERROR("message({$message->id}) sended unknow error,errors:".$e->getMessage());
                   //ignore
               }
            }
        }
        
        return parent::content_result('ok');
    }
    
    public function member_expire_check(){
        global $wpdb;
        $now = date('Y-m-d H:i:s',current_time( 'timestamp' )+7*24*60*60);
        $end =date_i18n('Y-m-d');
        $i=5;
       
        while ($i-->0){
            $expired_customer = $wpdb->get_row(
               "select m.id,
                       m.email,
                       m.pt_amount
                from member m
                where m.pt_amount<=2.99
                      and m.expire_warning = 0
                limit 1;");
            
            if(!$expired_customer){
                return parent::content_result('ok');
            }
            
            $update =$wpdb->update('member', array(
                'expire_warning'=>1
            ), array(
                'id'=>$expired_customer->id
            ));
            
            if(!$update){
                //说明已被其他线程处理
                continue;
            }
          
            try {
                $wpdb->insert('message', array(
                    'content'=>json_encode(array(
                        'type'=>'email',
                        'emails'=>json_encode(array($expired_customer->email)),
                        'subject'=>"【虎皮椒】您的平台使用费即将消费完毕",
                        'content'=> "您好，您的<a href='https://admin.xunhupay.com/'>虎皮椒</a>平台使用费即将消费完毕，请您注意！<br/>平台使用费余额为￥{$expired_customer->pt_amount}，过期后将无法结算。<br/>请注意时间，防止过期失效，请及时<a href='https://admin.xunhupay.com/employees/recharge/index'>充值续费</a>"
                    )),
                    'created_time'=>date_i18n('Y-m-d H:i:s'),
                    'status'=>'A'
               ));
                
               
            } catch (Exception $e) {
                $logger = new XH_Log ( 'member' );
                $logger->ERROR ( $e->getMessage () );
            }
        }
        
        return parent::content_result('ok');
    }
}