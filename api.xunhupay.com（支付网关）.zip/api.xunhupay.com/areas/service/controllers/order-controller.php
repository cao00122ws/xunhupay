<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once ABSPATH.'extensions/abstract-web-controller.php';
class Order_Controller extends Web_Abstract_Controller{
    public function sync_order_callback($i=2){ 
        global $wpdb;
     
        $service_id = XH_Common::guid();
        $now =date('Y-m-d H:i:s',current_time( 'timestamp' ) -24*60*60);
        $wpdb->query(
            "update `order` o
             set o.service_id='$service_id'
             where o.check_callback_time<1
                  and o.status='OD'
				  and o.order_date>'$now'
             limit 10;");
        
        if(!empty($wpdb->last_error)){
            $logger = new XH_Log();
            $logger->ERROR($wpdb->last_error);
            return $this->content_result($wpdb->last_error);
        }
        
        $orders =$wpdb->get_results(
            "select o.id,
        	        o.appid,
                    o.trade_order_id,
    				o.transaction_id,
        	        o.status,
                    a.id as appid,
                    o.total_amount,
                    o.order_date,
                    o.notify_url,
                    o.title,
                    a.appkey,
	                o.plugins,
                    o.attach,
    	            a.name as app_name,
                    o.check_callback_time,
                    a.member_id
            from `order` o
            inner join app a on a.id = o.appid
            where o.check_callback_time<1
                  and o.status='OD'
                  and o.service_id='$service_id'
            limit 10;");
    
        if(!$orders||count($orders)<=0){
            return $this->content_result('success');
        }
    
        foreach ($orders as $order){
            $result=$wpdb->query(
                "update `order` o
                 set o.check_callback_time=(o.check_callback_time+1)
                 where o.id={$order->id}
                       and o.status='OD'");
    
            if(!empty($wpdb->last_error)){
                $logger = new XH_Log('service');
                $logger->ERROR($wpdb->last_error);
                continue;
            }
            if(!$result){
                return;
            }
           try {
               $this->order_notify_callback($order);
           } catch (Exception $e) {
               $logger = new XH_Log();
               $logger->ERROR($e->getMessage());
           }
        }
        
        return $this->content_result('success');
    }
  
  
  public function callback($id){ 
        global $wpdb;
     	$id = absint($id);
        $service_id = XH_Common::guid();
        $now =date('Y-m-d H:i:s',current_time( 'timestamp' ) -24*60*60);
       
        $orders =$wpdb->get_results(
            "select o.id,
        	        o.appid,
                    o.trade_order_id,
    				o.transaction_id,
        	        o.status,
                    a.id as appid,
                    o.total_amount,
                    o.order_date,
                    o.notify_url,
                    o.title,
                    a.appkey,
	                o.plugins,
                    o.attach,
    	            a.name as app_name,
                    o.check_callback_time,
                    a.member_id
            from `order` o
            inner join app a on a.id = o.appid
            where o.id={$id}
            	  and o.status='OD'
            limit 1;");
    
        if(!$orders||count($orders)<=0){
            return $this->content_result('order not found!');
        }
    
        foreach ($orders as $order){
           try {
               $this->order_notify_callback($order);
           } catch (Exception $e) {
               $logger = new XH_Log();
               $logger->ERROR($e->getMessage());
             echo $e->getMessage();
           }
        }
         global $callback_error;
        return $this->content_result($callback_error);
    }
}