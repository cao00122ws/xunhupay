<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
class XH_Service_Area_Registration extends XH_Abstract_Area_Registration {
	/**
	 * 获取area
	 */
	public function get_area() {
		return 'service';
	}
	
	/**
	 * 注册路由
	 * 
	 * @param XH_Route_Conllection $routes        	
	 */
	public function register_routes($routes) {
      
		$routes->map_route('service/order/checkcallback.html', array(
		    'action'=>'sync_order_callback',
		    'controller'=>'order'
		));
		
		$routes->map_route('service/message.html', array(
		    'action'=>'index',
		    'controller'=>'msg'
		));
		
		$routes->map_route('service/member/expire.html', array(
		    'action'=>'member_expire_check',
		    'controller'=>'msg'
		));
       //人工模拟回调
        $routes->map_route('order/callback.html', array(
		    'action'=>'callback',
		    'controller'=>'order'
		));
	}
}