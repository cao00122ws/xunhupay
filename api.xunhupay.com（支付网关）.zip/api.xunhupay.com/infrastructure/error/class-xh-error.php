<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
require_once 'abstract-xh-error.php';
class XH_Error extends XH_Abstract_Error{
	public function __construct($errcode=0, $errmsg='',$data=null) {
		parent::__construct();
		
		$this->errcode = $errcode;
		$this->errmsg = $errmsg;
		$this->data=$data;
	}
	public static function success($data=null) {
		return new XH_Error ( 0, '' ,$data);
	}
	public static function error_unknow() {
		return XH_Error::get_error(400);
	}
	public static function error_custom($errmsg) {
		return new XH_Error ( - 1, $errmsg );
	}
	public function to_json() {
		return XH_Common::json_encode_ex ( array(
				'errcode'=>$this->errcode,
				'errmsg'=>$this->errmsg,
				'data'=>$this->data
		) );
	}
	
	
	public $errcode;
	public $errmsg;
	public $data;
}