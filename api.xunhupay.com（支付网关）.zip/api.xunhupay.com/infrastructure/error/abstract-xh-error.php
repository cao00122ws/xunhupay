<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
abstract class  XH_Abstract_Error {
	var $errors;
	public function __construct() {
		$this->errors = array (
				300=>'网络异常，请稍候重试！',
				400 => '未知的错误！',
				404 => '请求地址未找到！',
				405 => '该账户已被冻结！',
				500 =>'系统内部错误！',
				501 =>'未授权的访问！',
				574=>'短信发送失败，请稍候重试！',
				600 => '错误的请求！' ,
				700 => '您尝试请求的次数过多！',
		);
	}
	
	public static $instance;
	public static function get_instance() {
		if (self::$instance && self::$instance instanceof XH_Abstract_Error) {
			return self::$instance;
		}
		
		self::$instance = new XH_Error ();
		return self::$instance;
	}
	
	public static function get_error($err_code) {
		$self = self::get_instance ();
		if (! $self || ! $self->errors) {
			return XH_Error::error_unknow ();
		}
		
		foreach ( $self->errors as $key => $msg ) {
			if ($key == $err_code) {
				return new XH_Error ( $key, $msg );
			}
		}
		
		return XH_Error::error_unknow ();
	}
	
	/**
	 * 验证
	 * 
	 * @param
	 *        	XH_Error &$xh_error
	 * @return bool
	 */
	public static function is_valid(&$xh_error) {
		if (! $xh_error || ! ($xh_error instanceof XH_Error)) {
			$xh_error = XH_Error::error_unknow ();
			return false;
		}
		
		return $xh_error->errcode == 0;
	}
}