<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
class XH_Common {
    public static function generate_xh_hash(array $datas,$hashkey){
        ksort($datas);
        reset($datas);
         
        $pre =array();
        foreach ($datas as $key => $data){
            if(is_null($data)||$data===''){
                continue;
            }
            if($key=='hash'){
                continue;
            }
             
            $pre[$key]=$data;
        }
         
        $arg  = '';
        $qty = count($pre);
        $index=0;
         
        foreach ($pre as $key=>$val){
            $arg.="$key=$val";
            if($index++<($qty-1)){
                $arg.="&";
            }
        }
         
        return md5($arg.$hashkey);
    }
    
    public static function get($array,$key,$default =null){
        if(!$array){
            return $default;
        }
    
        return isset($array[$key])?$array[$key]:$default;
    }
    public static function stripslashes($arg){
        if(get_magic_quotes_gpc()){return stripslashes($arg);}
        return $arg;
    }
    
    public static function get_client_ip() {
        $ip =getenv('HTTP_CLIENT_IP');
        if($ip && strcasecmp($ip, 'unknown')) {
            return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : null;
        }
    
        $ip =getenv('HTTP_X_FORWARDED_FOR');
        if($ip && strcasecmp($ip, 'unknown')) {
            return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : null;
        }
    
        $ip =getenv('REMOTE_ADDR');
        if($ip && strcasecmp($ip, 'unknown')) {
            return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : null;
        }
    
        $ip =isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:null;
        if($ip && strcasecmp($ip, 'unknown')) {
            return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : null;
        }
    
        return null;
    }
    public static function guid(){
        $guid='';
        if (function_exists('com_create_guid')){
            $guid= com_create_guid();
        }else{
            mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45);// "-"
            $uuid = chr(123)// "{"
            .substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12)
            .chr(125);// "}"
            $guid= $uuid;
        }
    
        return str_replace('-', '', trim($guid,'{}'));
    }

    public static function isMobile($mobile){
        if(empty($mobile)){
            return false;
        }
    
        $ipadchar = '/^\d{11}$/';
        $res=null;
        preg_match($ipadchar,$mobile,$res);
        return $res&&count($res)>0;
    }
    
    public static function isTel($mobile){
        if(empty($mobile)){
            return false;
        }
    
        $ipadchar = '/^[\d\-]+$/';
        $res=null;
        preg_match($ipadchar,$mobile,$res);
        return $res&&count($res)>0;
    }
    
    public static function isEmail($email){
        return is_email($email);
    }
    public static function isIOS(){
        $ua =isset($_SERVER['HTTP_USER_AGENT'])?$_SERVER['HTTP_USER_AGENT']:'';
        return strripos($ua,'iphone')!=false||strripos($ua,'ipad')!=false;
    }
    
    public static function isAndroid(){
        return isset($_SERVER['HTTP_USER_AGENT'])&&strripos($_SERVER['HTTP_USER_AGENT'],'android')!=false;
    }
    
	public static function isWeixinClient(){
		return isset($_SERVER['HTTP_USER_AGENT'])&&strripos($_SERVER['HTTP_USER_AGENT'],'micromessenger');
	}

	public static function first_to_upper($str){
		if(is_null($str)||!is_string($str)||strlen($str)==0){
			return $str;
		}
	
		return strtoupper($str[0]).substr($str, 1);
	}
	
	
	public static function isWebApp(){
		if(!isset($_SERVER['HTTP_USER_AGENT'])){
			return false;
		}
	
		$u=strtolower($_SERVER['HTTP_USER_AGENT']);
		if($u==null||strlen($u)==0){
			return false;
		}
	
		preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/',$u,$res);
	
		if($res&&count($res)>0){
			return true;
		}
	
		if(strlen($u)<4){
			return false;
		}
	
		preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/',substr($u,0,4),$res);
		if($res&&count($res)>0){
			return true;
		}
	
		$ipadchar = "/(ipad|ipad2)/i";
		preg_match($ipadchar,$u,$res);
		return $res&&count($res)>0;
	}
	
	/**
	 * 截断中文字符串
	 * 
	 * @param string $msg
	 * @param int $limit
	 * @param string $trimmarker
	 * @return string
	 */
	public static function strimwidth($msg, $limit, $trimmarker = '...') {
		if (mb_strlen( $msg ) <= $limit) {
			return $msg;
		}
		
		return mb_strimwidth ( $msg, 0, $limit, $trimmarker );
	}
	
	/**
	 * 对变量进行 JSON 编码
	 * 
	 * @param mixed value 待编码的 value ，除了resource 类型之外，可以为任何数据类型，该函数只能接受 UTF-8 编码的数据
	 * @return string 返回 value 值的 JSON 形式
	 */
	public static function json_encode_ex($value) {
		return json_encode ( $value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE );
	}
}