<?php
class Array_Extension{
	public static function is_null_or_empty($array){
		return $array==null||!is_array($array)||count($array)==0;
	}
	
	public static function first_or_default($array,$func,$params =null){
		if(self::is_null_or_empty($array)){
			return null;
		}
	
		foreach ($array as $item){
			if(call_user_func_array($func, array($item,$params))){return $item;}
		}
	
		return null;
	}
	
	public static function any($array,$func,$params =null){
		if(self::is_null_or_empty($array)){
			return false;
		}
		
		foreach ($array as $item){
			if(call_user_func_array($func, array($item,$params))){return true;}
		}
		
		return false;
	}
	
	public static function sum($array,$func,$params =null){
		if(self::is_null_or_empty($array)){
			return 0;
		}
	
		$results=0;
		foreach ($array as $item){
			$results+=call_user_func_array($func, array($item,$params));
		}
		return $results;
	}
	
	public static function select($array,$func,$params =null){
		if(self::is_null_or_empty($array)){
			return false;
		}
		
		$results=array();
		foreach ($array as $item){
			$results[]=call_user_func_array($func, array($item,$params));
		}
		return $results;
	}
	
	public static function where($array,$func,$params =null){
		if(self::is_null_or_empty($array)){
			return $array;
		}
		
		$results=array();
		foreach ($array as $item){
			if(call_user_func_array($func, array($item,$params))){
				$results[]=$item;
			}
		}
	
		return $results;
	}
}