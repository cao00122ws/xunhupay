<?php
class XH_DB_Helper{
	private $table,$idname;
	public function __construct($table,$idname='id'){
		$this->table = $table;
		$this->idname = $idname;
	}
	
	/**
	 * 查询一条
	 * @param mixed $id
	 * @param array|string $where
	 * @param string $orderby
	 * @param string $params
	 * @return null|object
	 */
	public function get($id,$where=array(),$orderby='',$params="*"){
		global $wpdb;
		$table = $this->table;
		
		$wheresql ='';
		$has_fix = false;
		if($where){
			if(is_array($where)){
				if(count($where)>0){
					$has_fix=true;
					foreach ($where as $key=>$val){
						$wheresql.=" and ".$key="%s";
					}
				}
			}else if(is_string($where)){
				if(strlen($where)>0){
					$has_fix=true;
				}
				$wheresql='and '.$where;
			}
		}
		
		$idname =$this->idname;
		if($has_fix){
			return $wpdb->get_row($this->prepare("select $params from $table where $idname=%s $wheresql $orderby limit 1 ;", $id));
		}
		return $wpdb->get_row($this->prepare("select $params from $table where $idname=%s $orderby limit 1 ;", $id));		
	}
	
	/**
	 * Prepares a SQL query for safe execution. Uses sprintf()-like syntax.
	 *
	 * The following directives can be used in the query format string:
	 *   %d (integer)
	 *   %f (float)
	 *   %s (string)
	 *   %% (literal percentage sign - no argument needed)
	 *
	 * All of %d, %f, and %s are to be left unquoted in the query string and they need an argument passed for them.
	 * Literals (%) as parts of the query must be properly written as %%.
	 *
	 * This function only supports a small subset of the sprintf syntax; it only supports %d (integer), %f (float), and %s (string).
	 * Does not support sign, padding, alignment, width or precision specifiers.
	 * Does not support argument numbering/swapping.
	 *
	 * May be called like {@link http://php.net/sprintf sprintf()} or like {@link http://php.net/vsprintf vsprintf()}.
	 *
	 * Both %d and %s should be left unquoted in the query string.
	 *
	 *     wpdb::prepare( "SELECT * FROM `table` WHERE `column` = %s AND `field` = %d", 'foo', 1337 )
	 *     wpdb::prepare( "SELECT DATE_FORMAT(`field`, '%%c') FROM `table` WHERE `column` = %s", 'foo' );
	 *
	 * @link http://php.net/sprintf Description of syntax.
	 * @since 2.3.0
	 *
	 * @param string      $query    Query statement with sprintf()-like placeholders
	 * @param array|mixed $args     The array of variables to substitute into the query's placeholders if being called like
	 *                              {@link http://php.net/vsprintf vsprintf()}, or the first variable to substitute into the query's placeholders if
	 *                              being called like {@link http://php.net/sprintf sprintf()}.
	 * @param mixed       $args,... further variables to substitute into the query's placeholders if being called like
	 *                              {@link http://php.net/sprintf sprintf()}.
	 * @return string|void Sanitized query string, if there is a query to prepare.
	 */
	public function prepare($query,$args){
		$args = func_get_args();
		array_shift( $args );
		// If args were passed as an array (as in vsprintf), move them up
		if ( isset( $args[0] ) && is_array($args[0]) )
			$args = $args[0];
		
		global $wpdb;
		$result = $wpdb->prepare($query, $args);
		if(empty($result)){
			throw new Exception("$query returns empty!");
		}
		
		return $result;
	}
	
	/**
	 * 查询
	 * @param string|array $where
	 * @param string $orderby
	 * @param number $limit
	 * @param string $params
	 * @param string $callback
	 * @return null|array
	 */
	public function get_all($where=array(),$orderby='',$limit=null,$params="*",$callback=null){
		global $wpdb;
		$table = $this->table;
	
		$wheresql ='';
		$has_fix = false;
		if($where){
			if(is_array($where)){
				if(count($where)>0){
					$has_fix=true;
					$index=0;
					foreach ($where as $key=>$val){
						if($index++>0){
							$wheresql.=' and ';
						}
						$wheresql.=" and ".$key="%s";
					}
				}
			}else  if(is_string($where)){
				if(strlen($where)>0){
					$has_fix=true;
				}
				$wheresql=$where;
			}
		}
		
		$results =null;
		if($has_fix){
			$results =$wpdb->get_results("select $params from $table where  $wheresql $orderby $limit ;");
		}else{
			$results= $wpdb->get_results("select $params from $table $orderby $limit ;");
		}
		
		if($callback&&$results){
			for ($index =0;$index<count($results);$index++){
				call_user_func_array($callback, array($results[$index],$index));
			}
		}
		
		return $results;
	}
	
	/**
	 * 新增
	 * @param array $obj
	 * @return XH_Error
	 */
	public function add(&$obj){
		global $wpdb;
		$table = $this->table;
		$obj=(array) $obj;
		try {
			$wpdb->insert($table,$obj);
		} catch (Exception $e) {
			$logger = new XH_Log();
			$logger->ERROR($e->getMessage());
			return XH_Error::get_error(500);
		}
		
		$idname =$this->idname;
		
		if(!isset($obj[$idname])||(is_numeric($obj[$idname])&&$obj[$idname]==0)){
			if($wpdb->insert_id>0){
				$obj[$idname]=$wpdb->insert_id;
			}
		}
		
		if(!empty($wpdb->last_error)){
			$logger = new XH_Log();
			$logger->ERROR($wpdb->last_error);
			return XH_Error::get_error(500);
		}
		
		return XH_Error::success();
	}
	
	/**
	 * 查询数量
	 * @param array|string $where
	 * @return number
	 */
	public function count($where=array()){
		global $wpdb;
		$table = $this->table;
		$idname = $this->idname;
		
		$wheresql ='';
		$has_fix = false;
		if($where){
			if(is_array($where)){
				if(count($where)>0){
					$has_fix=true;
					$index=0;
					foreach ($where as $key=>$val){
						if($index++>0){
							$wheresql.=' and ';
						}
						$wheresql.=" and ".$key="%s";
					}
				}
			}else  if(is_string($where)){
				
				if(strlen($where)>0){
					$has_fix=true;
				}
				$wheresql=$where;
			}	
		}
	
		$query=null;
		if($has_fix){
			$query = $wpdb->get_row("select count($idname) as qty from $table where  $wheresql;");
		}else{
			$query = $wpdb->get_row("select count($idname) as qty from $table;");
		}
		
		return $query?$query->qty:0;
	}
	
	/**
	 * 更新
	 * @param array $data
	 * @param array $where
	 * @return XH_Error
	 */
	public function modify($data,$where){
		global $wpdb;
		$table = $this->table;
		try {
			$wpdb->update($table, $data, $where);
		} catch (Exception $e) {
			$logger = new XH_Log();
			$logger->ERROR($e->getMessage());
			return XH_Error::get_error(500);
		}
		if(!empty($wpdb->last_error)){
			$logger = new XH_Log();
			$logger->ERROR($wpdb->last_error);
			return XH_Error::get_error(500);
		}
		
		return XH_Error::success();
	}
	
	/**
	 * 新增或更新
	 * @param array $data
	 * @param string $where
	 * @param function $isnewCallback
	 */
	public function save_or_update(&$data,$isnewCallback){
		global $wpdb;
		$table = $this->table;
		if(call_user_func($isnewCallback, $data)){			
			return $this->add($data);
		}else{
			return $this->modify($data,array(
					$this->idname=>$data[$this->idname]
			));
		}
	}
	
	/**
	 * 删除
	 * @param array $where
	 * @return XH_Error
	 */
	public function remove($where=array()){
		global $wpdb;
		$table = $this->table;
		try {
			$wpdb->delete($table, $where);
		} catch (Exception $e) {
			$logger = new XH_Log();
			$logger->ERROR($e->getMessage());
			return XH_Error::get_error(500);
		}
		
		if(!empty($wpdb->last_error)){
			$logger = new XH_Log();
			$logger->ERROR($wpdb->last_error);
			return XH_Error::get_error(500);
		}
	
		return XH_Error::success();
	}
}