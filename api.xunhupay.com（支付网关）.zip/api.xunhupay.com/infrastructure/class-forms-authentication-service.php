<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
class forms_authentication_service{
	const AUTH_KEY='_authorized_wechat_';
	public static function is_authorized($cookiekey) {
		return self::get_auth_cookie($cookiekey)!=null;
	}
	
	public static function set_auth_cookie($user_id, $remember = false) {
		$data =$user_id;
		
		$salt = XH_Wx_Pay_Config::$APPID;
		$key = hash_hmac('md5', $data, $salt);
		$hash = hash_hmac('md5', $data, $key);
		
		$data =$user_id.'|'.$hash;
		setcookie(self::AUTH_KEY,urlencode($data), $remember?(time () + 60*60*24*3):null, '/', $_SERVER['HTTP_HOST'], false);
	}

	public static function clear_auth_cookie(){
		setcookie(self::AUTH_KEY,null, -1, '/',  $_SERVER['HTTP_HOST'], false);
	}
	
	public static function get_auth_cookie() {
		$cookiekey = self::AUTH_KEY;
		$cookie = isset($_COOKIE[$cookiekey])?$_COOKIE[$cookiekey]:'';
		if(empty($cookie)){
			return null;
		}
		
		$hashs = explode('|',urldecode($cookie),2);
		if(count($hashs)!=2){
			return null;
		}
		
		$data =$hashs[0];
		$salt = XH_Wx_Pay_Config::$APPID;
		$key = hash_hmac('md5', $data, $salt);
		$hash = hash_hmac('md5', $data, $key);
		if($hash!=$hashs[1]){
			return null;
		}
		
		$user_id =intval($data);
	   // $user_id=15;
		global $wpdb;
		$customer = $wpdb->get_row($wpdb->prepare(
										"select m.*
										from customer m
										where m.id =%d
										limit 1;", $user_id));
		
		if(!$customer||$customer->id<=0){
			return null;
		}
	
		return $customer;
	}
}

