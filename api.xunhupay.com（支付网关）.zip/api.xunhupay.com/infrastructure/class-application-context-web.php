<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'class-forms-authentication-service.php';

class application_context{
	
	public static function get_authorized(){
	    return forms_authentication_service::get_auth_cookie();
	}
}