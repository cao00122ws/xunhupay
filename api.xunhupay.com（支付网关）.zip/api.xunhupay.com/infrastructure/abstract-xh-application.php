<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'extensions/class-xh-common.php';
require_once 'extensions/class-array-extension.php';
require_once 'error/class-xh-error.php';
require_once 'db/class-db-helper.php';
require_once 'JWT.php';
abstract class XH_Abstract_Application {
	public function __construct() {
		$this->app_start ();
		
		register_shutdown_function( array($this,'app_end'));
		set_error_handler(array($this,'on_error'));
		set_exception_handler(array($this,'on_error'));
		
		require_once 'mvc/route/class-xh-route.php';			
		$route = new XH_Route ( $this );
		$result =$route->execute ();
		
		if(!$result){
		    $this->no_found();
		}
		exit;
	}
	
	public function app_start() {
		ini_set ( 'date.timezone', 'Asia/Shanghai' );
		header ( 'X-Powered-By: 迅虎网络' );
	}
	
	public function app_end() {
	    global $XH_SESSION;
	    if($XH_SESSION){
    	    $XH_SESSION->set_customer_session_cookie();
    	    $XH_SESSION->save_data();
	    }
	}
	
	public function no_found(){
	    ob_start();
	    @require_once ABSPATH.'404.phtml';
	    echo ob_get_clean();
	}
	
	/**
	 *
	 * @param Exception $e        	
	 */
	public function on_error($errno, $errstr=null, $errfile=null, $errline=null) {
	    
	    $MSG ='';
	    if($errno instanceof Exception){
	       $MSG=$errno->getMessage();
	    }else{
	        $MSG= "errno:$errno, errstr:$errstr, errfile:$errfile, errline:$errline";
	    }
	    
	    if(!class_exists('XH_Log')&&WP_DEBUG){
	        echo $MSG;
	        return;
	    }
	    
	    try {
	        require_once 'logger/class-xh-log.php';
	       $logger=new XH_Log('error');
	        $logger->DEBUG($MSG);
	    } catch (Exception $e) {
	        //ignore
	    }
	    
	    if(WP_DEBUG){
	        echo $MSG; 
	    }
	}
}